﻿namespace oprdracht2_APPR_race
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pbxRacer1SM = new System.Windows.Forms.PictureBox();
            this.pnlFinishSM = new System.Windows.Forms.Panel();
            this.pbxRacer2SM = new System.Windows.Forms.PictureBox();
            this.pbxRacer3SM = new System.Windows.Forms.PictureBox();
            this.btnGoSM = new System.Windows.Forms.Button();
            this.btnResetSM = new System.Windows.Forms.Button();
            this.tbcMainSM = new System.Windows.Forms.TabControl();
            this.tbpMainRaceSM = new System.Windows.Forms.TabPage();
            this.label72 = new System.Windows.Forms.Label();
            this.pnlpaintSM = new System.Windows.Forms.Panel();
            this.btnAgainSM = new System.Windows.Forms.Button();
            this.pbxRacer4SM = new System.Windows.Forms.PictureBox();
            this.panel64 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.lblRaceTimeSM = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.lblRank4SM = new System.Windows.Forms.Label();
            this.lblRank3SM = new System.Windows.Forms.Label();
            this.lblRank1SM = new System.Windows.Forms.Label();
            this.lblRank2SM = new System.Windows.Forms.Label();
            this.lblRacer4SM = new System.Windows.Forms.Label();
            this.lblRacer3SM = new System.Windows.Forms.Label();
            this.lblRacer2SM = new System.Windows.Forms.Label();
            this.lblRacer1SM = new System.Windows.Forms.Label();
            this.pbxRacer4TrailSM = new System.Windows.Forms.PictureBox();
            this.pbxRacer3TrailSM = new System.Windows.Forms.PictureBox();
            this.pbxRacer1TrailSM = new System.Windows.Forms.PictureBox();
            this.pbxRacer2TrailSM = new System.Windows.Forms.PictureBox();
            this.tbpMainSettingsSM = new System.Windows.Forms.TabPage();
            this.rtbSettingsSM = new System.Windows.Forms.RichTextBox();
            this.txbRacerName3SM = new System.Windows.Forms.TextBox();
            this.txbRacerName4SM = new System.Windows.Forms.TextBox();
            this.txbRacerName2SM = new System.Windows.Forms.TextBox();
            this.txbRacerName1SM = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.lblStapsizeTick4SM = new System.Windows.Forms.Label();
            this.lblStapsizeTick2SM = new System.Windows.Forms.Label();
            this.lblStapsizeTick3SM = new System.Windows.Forms.Label();
            this.lblStapsizeTick1SM = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.lblEngine3SM = new System.Windows.Forms.Label();
            this.lblEngine1SM = new System.Windows.Forms.Label();
            this.lblEngine4SM = new System.Windows.Forms.Label();
            this.lblEngine2SM = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.btnSetupRacers = new System.Windows.Forms.Button();
            this.btnDefaultSM = new System.Windows.Forms.Button();
            this.txbMaxSpeedSM = new System.Windows.Forms.TextBox();
            this.txbMinSpeedSM = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.tbpMainCasinoSM = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.rtbCasinoSM = new System.Windows.Forms.RichTextBox();
            this.lblRoulette34SM = new System.Windows.Forms.Label();
            this.gbxrouletteSM = new System.Windows.Forms.GroupBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.rbnRoulette7SM = new System.Windows.Forms.RadioButton();
            this.label22 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbnRoulette1SM = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.panel61 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.rbnRoulette0SM = new System.Windows.Forms.RadioButton();
            this.label51 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.rbnRoulette2SM = new System.Windows.Forms.RadioButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.rbnRoulette36SM = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rbnRoulette3SM = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.rbnRoulette33SM = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rbnRoulette4SM = new System.Windows.Forms.RadioButton();
            this.label19 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.rbnRoulette32SM = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.rbnRoulette8SM = new System.Windows.Forms.RadioButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.rbnRoulette35SM = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.rbnRoulette5SM = new System.Windows.Forms.RadioButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.rbnRoulette34SM = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.rbnRoulette6SM = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.rbnRoulette31SM = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.rbnRoulette9SM = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.rbnRoulette30SM = new System.Windows.Forms.RadioButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.rbnRoulette10SM = new System.Windows.Forms.RadioButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.rbnRoulette29SM = new System.Windows.Forms.RadioButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.rbnRoulette11SM = new System.Windows.Forms.RadioButton();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.rbnRoulette28SM = new System.Windows.Forms.RadioButton();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.rbnRoulette12SM = new System.Windows.Forms.RadioButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.rbnRoulette27SM = new System.Windows.Forms.RadioButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.rbnRoulette13SM = new System.Windows.Forms.RadioButton();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.rbnRoulette24SM = new System.Windows.Forms.RadioButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.rbnRoulette16SM = new System.Windows.Forms.RadioButton();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.rbnRoulette23SM = new System.Windows.Forms.RadioButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.rbnRoulette17SM = new System.Windows.Forms.RadioButton();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.rbnRoulette26SM = new System.Windows.Forms.RadioButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.rbnRoulette14SM = new System.Windows.Forms.RadioButton();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.rbnRoulette25SM = new System.Windows.Forms.RadioButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.rbnRoulette15SM = new System.Windows.Forms.RadioButton();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.rbnRoulette22SM = new System.Windows.Forms.RadioButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.rbnRoulette18SM = new System.Windows.Forms.RadioButton();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.rbnRoulette21SM = new System.Windows.Forms.RadioButton();
            this.panel36 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.rbnRoulette19SM = new System.Windows.Forms.RadioButton();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label48 = new System.Windows.Forms.Label();
            this.rbnRoulette20SM = new System.Windows.Forms.RadioButton();
            this.lblRoulette0SM = new System.Windows.Forms.Label();
            this.tbxRouletteSM = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnRouletteGoSM = new System.Windows.Forms.Button();
            this.lblRoulette36SM = new System.Windows.Forms.Label();
            this.lblRoulette35SM = new System.Windows.Forms.Label();
            this.lblRoulette33SM = new System.Windows.Forms.Label();
            this.lblRoulette32SM = new System.Windows.Forms.Label();
            this.lblRoulette31SM = new System.Windows.Forms.Label();
            this.lblRoulette30SM = new System.Windows.Forms.Label();
            this.lblRoulette26SM = new System.Windows.Forms.Label();
            this.lblRoulette27SM = new System.Windows.Forms.Label();
            this.lblRoulette29SM = new System.Windows.Forms.Label();
            this.lblRoulette28SM = new System.Windows.Forms.Label();
            this.lblRoulette25SM = new System.Windows.Forms.Label();
            this.lblRoulette23SM = new System.Windows.Forms.Label();
            this.lblRoulette22SM = new System.Windows.Forms.Label();
            this.lblRoulette24SM = new System.Windows.Forms.Label();
            this.lblRoulette20SM = new System.Windows.Forms.Label();
            this.lblRoulette17SM = new System.Windows.Forms.Label();
            this.lblRoulette16SM = new System.Windows.Forms.Label();
            this.lblRoulette19SM = new System.Windows.Forms.Label();
            this.lblRoulette18SM = new System.Windows.Forms.Label();
            this.lblRoulette15SM = new System.Windows.Forms.Label();
            this.lblRoulette12SM = new System.Windows.Forms.Label();
            this.lblRoulette10SM = new System.Windows.Forms.Label();
            this.lblRoulette14SM = new System.Windows.Forms.Label();
            this.lblRoulette11SM = new System.Windows.Forms.Label();
            this.lblRoulette9SM = new System.Windows.Forms.Label();
            this.lblRoulette13SM = new System.Windows.Forms.Label();
            this.lblRoulette8SM = new System.Windows.Forms.Label();
            this.lblRoulette7SM = new System.Windows.Forms.Label();
            this.lblRoulette6SM = new System.Windows.Forms.Label();
            this.lblRoulette5SM = new System.Windows.Forms.Label();
            this.lblRoulette4SM = new System.Windows.Forms.Label();
            this.lblRoulette3SM = new System.Windows.Forms.Label();
            this.lblRoulette2SM = new System.Windows.Forms.Label();
            this.lblRoulette1SM = new System.Windows.Forms.Label();
            this.lblBetsLostSM = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblBetsWonSM = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblBettingOnSM = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxBet3SM = new System.Windows.Forms.TextBox();
            this.tbxBet4SM = new System.Windows.Forms.TextBox();
            this.tbxBet1SM = new System.Windows.Forms.TextBox();
            this.tbxBet2SM = new System.Windows.Forms.TextBox();
            this.btnBet4SM = new System.Windows.Forms.Button();
            this.btnBet3SM = new System.Windows.Forms.Button();
            this.btnBet2SM = new System.Windows.Forms.Button();
            this.btnBet1SM = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCoinsSM = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRoulette21SM = new System.Windows.Forms.Label();
            this.tbpstartSM = new System.Windows.Forms.TabPage();
            this.btnStartScreen = new System.Windows.Forms.Button();
            this.pbxStartScreen2SM = new System.Windows.Forms.PictureBox();
            this.pbxstartSM = new System.Windows.Forms.PictureBox();
            this.tbpMainHelpSM = new System.Windows.Forms.TabPage();
            this.gbxHelpCasinoSM = new System.Windows.Forms.GroupBox();
            this.btnToRaceSM = new System.Windows.Forms.Button();
            this.pbxHelpWonSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpRouletteSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpCloggingSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpBetSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpCoinsSM = new System.Windows.Forms.PictureBox();
            this.gbxHelpSettingsSM = new System.Windows.Forms.GroupBox();
            this.btnToCasinoSM = new System.Windows.Forms.Button();
            this.pbxHelpSetupSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpSloggingSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpSpeedSM = new System.Windows.Forms.PictureBox();
            this.gbxHelpRaceSM = new System.Windows.Forms.GroupBox();
            this.pbxHelpRaceSM = new System.Windows.Forms.PictureBox();
            this.btnToSettingsSM = new System.Windows.Forms.Button();
            this.pbxhelpBtnSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpTimeSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpRankingSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpDrawSM = new System.Windows.Forms.PictureBox();
            this.pbxHelpStageSM = new System.Windows.Forms.PictureBox();
            this.tbpMainAllLoggingSM = new System.Windows.Forms.TabPage();
            this.rtbAllLoggingSM = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.creatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vieuwToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theRaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loggingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.casinoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tmrRouletteSM = new System.Windows.Forms.Timer(this.components);
            this.panel37 = new System.Windows.Forms.Panel();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.panel38 = new System.Windows.Forms.Panel();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.panel39 = new System.Windows.Forms.Panel();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.panel40 = new System.Windows.Forms.Panel();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.panel41 = new System.Windows.Forms.Panel();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.panel42 = new System.Windows.Forms.Panel();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.panel43 = new System.Windows.Forms.Panel();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.panel44 = new System.Windows.Forms.Panel();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.panel45 = new System.Windows.Forms.Panel();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.panel46 = new System.Windows.Forms.Panel();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.panel47 = new System.Windows.Forms.Panel();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.panel48 = new System.Windows.Forms.Panel();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.panel49 = new System.Windows.Forms.Panel();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.panel50 = new System.Windows.Forms.Panel();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.panel51 = new System.Windows.Forms.Panel();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.panel52 = new System.Windows.Forms.Panel();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.panel53 = new System.Windows.Forms.Panel();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.panel54 = new System.Windows.Forms.Panel();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.panel55 = new System.Windows.Forms.Panel();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.panel56 = new System.Windows.Forms.Panel();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.panel57 = new System.Windows.Forms.Panel();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.panel58 = new System.Windows.Forms.Panel();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.panel59 = new System.Windows.Forms.Panel();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.panel60 = new System.Windows.Forms.Panel();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.tmrRaceSM = new System.Windows.Forms.Timer(this.components);
            this.tmrStartScreenSM = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer1SM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer2SM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer3SM)).BeginInit();
            this.tbcMainSM.SuspendLayout();
            this.tbpMainRaceSM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer4SM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer4TrailSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer3TrailSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer1TrailSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer2TrailSM)).BeginInit();
            this.tbpMainSettingsSM.SuspendLayout();
            this.tbpMainCasinoSM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.gbxrouletteSM.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel35.SuspendLayout();
            this.tbpstartSM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxStartScreen2SM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxstartSM)).BeginInit();
            this.tbpMainHelpSM.SuspendLayout();
            this.gbxHelpCasinoSM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpWonSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpRouletteSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpCloggingSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpBetSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpCoinsSM)).BeginInit();
            this.gbxHelpSettingsSM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpSetupSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpSloggingSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpSpeedSM)).BeginInit();
            this.gbxHelpRaceSM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpRaceSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxhelpBtnSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpTimeSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpRankingSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpDrawSM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpStageSM)).BeginInit();
            this.tbpMainAllLoggingSM.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel50.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel60.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbxRacer1SM
            // 
            this.pbxRacer1SM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer1SM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer1SM.Image")));
            this.pbxRacer1SM.Location = new System.Drawing.Point(4, 5);
            this.pbxRacer1SM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer1SM.Name = "pbxRacer1SM";
            this.pbxRacer1SM.Size = new System.Drawing.Size(82, 61);
            this.pbxRacer1SM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer1SM.TabIndex = 7;
            this.pbxRacer1SM.TabStop = false;
            // 
            // pnlFinishSM
            // 
            this.pnlFinishSM.BackColor = System.Drawing.Color.Black;
            this.pnlFinishSM.Location = new System.Drawing.Point(772, 2);
            this.pnlFinishSM.Margin = new System.Windows.Forms.Padding(2);
            this.pnlFinishSM.Name = "pnlFinishSM";
            this.pnlFinishSM.Size = new System.Drawing.Size(4, 267);
            this.pnlFinishSM.TabIndex = 6;
            // 
            // pbxRacer2SM
            // 
            this.pbxRacer2SM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer2SM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer2SM.Image")));
            this.pbxRacer2SM.Location = new System.Drawing.Point(4, 71);
            this.pbxRacer2SM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer2SM.Name = "pbxRacer2SM";
            this.pbxRacer2SM.Size = new System.Drawing.Size(82, 61);
            this.pbxRacer2SM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer2SM.TabIndex = 8;
            this.pbxRacer2SM.TabStop = false;
            // 
            // pbxRacer3SM
            // 
            this.pbxRacer3SM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer3SM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer3SM.Image")));
            this.pbxRacer3SM.Location = new System.Drawing.Point(4, 136);
            this.pbxRacer3SM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer3SM.Name = "pbxRacer3SM";
            this.pbxRacer3SM.Size = new System.Drawing.Size(82, 61);
            this.pbxRacer3SM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer3SM.TabIndex = 7;
            this.pbxRacer3SM.TabStop = false;
            // 
            // btnGoSM
            // 
            this.btnGoSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoSM.Location = new System.Drawing.Point(6, 268);
            this.btnGoSM.Margin = new System.Windows.Forms.Padding(2);
            this.btnGoSM.Name = "btnGoSM";
            this.btnGoSM.Size = new System.Drawing.Size(90, 48);
            this.btnGoSM.TabIndex = 7;
            this.btnGoSM.Text = "go!";
            this.btnGoSM.UseVisualStyleBackColor = true;
            this.btnGoSM.Click += new System.EventHandler(this.btnGoSM_Click);
            // 
            // btnResetSM
            // 
            this.btnResetSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetSM.Location = new System.Drawing.Point(6, 323);
            this.btnResetSM.Margin = new System.Windows.Forms.Padding(2);
            this.btnResetSM.Name = "btnResetSM";
            this.btnResetSM.Size = new System.Drawing.Size(41, 25);
            this.btnResetSM.TabIndex = 8;
            this.btnResetSM.Text = "reset";
            this.btnResetSM.UseVisualStyleBackColor = true;
            this.btnResetSM.Click += new System.EventHandler(this.btnResetSM_Click);
            // 
            // tbcMainSM
            // 
            this.tbcMainSM.Controls.Add(this.tbpMainRaceSM);
            this.tbcMainSM.Controls.Add(this.tbpMainSettingsSM);
            this.tbcMainSM.Controls.Add(this.tbpMainCasinoSM);
            this.tbcMainSM.Controls.Add(this.tbpstartSM);
            this.tbcMainSM.Controls.Add(this.tbpMainHelpSM);
            this.tbcMainSM.Controls.Add(this.tbpMainAllLoggingSM);
            this.tbcMainSM.Location = new System.Drawing.Point(0, 25);
            this.tbcMainSM.Margin = new System.Windows.Forms.Padding(2);
            this.tbcMainSM.Name = "tbcMainSM";
            this.tbcMainSM.SelectedIndex = 0;
            this.tbcMainSM.Size = new System.Drawing.Size(929, 516);
            this.tbcMainSM.TabIndex = 11;
            // 
            // tbpMainRaceSM
            // 
            this.tbpMainRaceSM.Controls.Add(this.label72);
            this.tbpMainRaceSM.Controls.Add(this.pnlpaintSM);
            this.tbpMainRaceSM.Controls.Add(this.btnAgainSM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer4SM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer3SM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer2SM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer1SM);
            this.tbpMainRaceSM.Controls.Add(this.panel64);
            this.tbpMainRaceSM.Controls.Add(this.panel63);
            this.tbpMainRaceSM.Controls.Add(this.panel62);
            this.tbpMainRaceSM.Controls.Add(this.lblRaceTimeSM);
            this.tbpMainRaceSM.Controls.Add(this.label60);
            this.tbpMainRaceSM.Controls.Add(this.pnlFinishSM);
            this.tbpMainRaceSM.Controls.Add(this.lblRank4SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRank3SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRank1SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRank2SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRacer4SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRacer3SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRacer2SM);
            this.tbpMainRaceSM.Controls.Add(this.lblRacer1SM);
            this.tbpMainRaceSM.Controls.Add(this.btnResetSM);
            this.tbpMainRaceSM.Controls.Add(this.btnGoSM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer4TrailSM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer3TrailSM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer1TrailSM);
            this.tbpMainRaceSM.Controls.Add(this.pbxRacer2TrailSM);
            this.tbpMainRaceSM.Location = new System.Drawing.Point(4, 22);
            this.tbpMainRaceSM.Margin = new System.Windows.Forms.Padding(2);
            this.tbpMainRaceSM.Name = "tbpMainRaceSM";
            this.tbpMainRaceSM.Padding = new System.Windows.Forms.Padding(2);
            this.tbpMainRaceSM.Size = new System.Drawing.Size(921, 490);
            this.tbpMainRaceSM.TabIndex = 0;
            this.tbpMainRaceSM.Text = "race";
            this.tbpMainRaceSM.UseVisualStyleBackColor = true;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(7, 358);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(72, 13);
            this.label72.TabIndex = 27;
            this.label72.Text = "racer ranking:";
            // 
            // pnlpaintSM
            // 
            this.pnlpaintSM.Location = new System.Drawing.Point(504, 278);
            this.pnlpaintSM.Name = "pnlpaintSM";
            this.pnlpaintSM.Size = new System.Drawing.Size(414, 212);
            this.pnlpaintSM.TabIndex = 26;
            // 
            // btnAgainSM
            // 
            this.btnAgainSM.Location = new System.Drawing.Point(55, 323);
            this.btnAgainSM.Margin = new System.Windows.Forms.Padding(2);
            this.btnAgainSM.Name = "btnAgainSM";
            this.btnAgainSM.Size = new System.Drawing.Size(41, 25);
            this.btnAgainSM.TabIndex = 25;
            this.btnAgainSM.Text = "again";
            this.btnAgainSM.UseVisualStyleBackColor = true;
            this.btnAgainSM.Click += new System.EventHandler(this.btnAgainSM_click);
            // 
            // pbxRacer4SM
            // 
            this.pbxRacer4SM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer4SM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer4SM.Image")));
            this.pbxRacer4SM.Location = new System.Drawing.Point(4, 202);
            this.pbxRacer4SM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer4SM.Name = "pbxRacer4SM";
            this.pbxRacer4SM.Size = new System.Drawing.Size(82, 61);
            this.pbxRacer4SM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer4SM.TabIndex = 8;
            this.pbxRacer4SM.TabStop = false;
            // 
            // panel64
            // 
            this.panel64.BackColor = System.Drawing.Color.Silver;
            this.panel64.Location = new System.Drawing.Point(122, 388);
            this.panel64.Margin = new System.Windows.Forms.Padding(2);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(82, 81);
            this.panel64.TabIndex = 23;
            // 
            // panel63
            // 
            this.panel63.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel63.BackgroundImage")));
            this.panel63.Location = new System.Drawing.Point(295, 429);
            this.panel63.Margin = new System.Windows.Forms.Padding(2);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(82, 41);
            this.panel63.TabIndex = 22;
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.Gold;
            this.panel62.Location = new System.Drawing.Point(208, 348);
            this.panel62.Margin = new System.Windows.Forms.Padding(2);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(82, 122);
            this.panel62.TabIndex = 21;
            // 
            // lblRaceTimeSM
            // 
            this.lblRaceTimeSM.AutoSize = true;
            this.lblRaceTimeSM.Location = new System.Drawing.Point(154, 268);
            this.lblRaceTimeSM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRaceTimeSM.Name = "lblRaceTimeSM";
            this.lblRaceTimeSM.Size = new System.Drawing.Size(16, 13);
            this.lblRaceTimeSM.TabIndex = 20;
            this.lblRaceTimeSM.Text = "---";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(100, 268);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(53, 13);
            this.label60.TabIndex = 19;
            this.label60.Text = "race time:";
            // 
            // lblRank4SM
            // 
            this.lblRank4SM.AutoSize = true;
            this.lblRank4SM.Location = new System.Drawing.Point(45, 459);
            this.lblRank4SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRank4SM.Name = "lblRank4SM";
            this.lblRank4SM.Size = new System.Drawing.Size(16, 13);
            this.lblRank4SM.TabIndex = 18;
            this.lblRank4SM.Text = "---";
            // 
            // lblRank3SM
            // 
            this.lblRank3SM.AutoSize = true;
            this.lblRank3SM.Location = new System.Drawing.Point(45, 430);
            this.lblRank3SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRank3SM.Name = "lblRank3SM";
            this.lblRank3SM.Size = new System.Drawing.Size(16, 13);
            this.lblRank3SM.TabIndex = 17;
            this.lblRank3SM.Text = "---";
            // 
            // lblRank1SM
            // 
            this.lblRank1SM.AutoSize = true;
            this.lblRank1SM.Location = new System.Drawing.Point(45, 379);
            this.lblRank1SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRank1SM.Name = "lblRank1SM";
            this.lblRank1SM.Size = new System.Drawing.Size(16, 13);
            this.lblRank1SM.TabIndex = 16;
            this.lblRank1SM.Text = "---";
            // 
            // lblRank2SM
            // 
            this.lblRank2SM.AutoSize = true;
            this.lblRank2SM.Location = new System.Drawing.Point(45, 404);
            this.lblRank2SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRank2SM.Name = "lblRank2SM";
            this.lblRank2SM.Size = new System.Drawing.Size(16, 13);
            this.lblRank2SM.TabIndex = 15;
            this.lblRank2SM.Text = "---";
            // 
            // lblRacer4SM
            // 
            this.lblRacer4SM.AutoSize = true;
            this.lblRacer4SM.Location = new System.Drawing.Point(7, 459);
            this.lblRacer4SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRacer4SM.Name = "lblRacer4SM";
            this.lblRacer4SM.Size = new System.Drawing.Size(43, 13);
            this.lblRacer4SM.TabIndex = 14;
            this.lblRacer4SM.Text = "racer 4:";
            // 
            // lblRacer3SM
            // 
            this.lblRacer3SM.AutoSize = true;
            this.lblRacer3SM.Location = new System.Drawing.Point(7, 430);
            this.lblRacer3SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRacer3SM.Name = "lblRacer3SM";
            this.lblRacer3SM.Size = new System.Drawing.Size(43, 13);
            this.lblRacer3SM.TabIndex = 13;
            this.lblRacer3SM.Text = "racer 3:";
            // 
            // lblRacer2SM
            // 
            this.lblRacer2SM.AutoSize = true;
            this.lblRacer2SM.Location = new System.Drawing.Point(7, 404);
            this.lblRacer2SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRacer2SM.Name = "lblRacer2SM";
            this.lblRacer2SM.Size = new System.Drawing.Size(43, 13);
            this.lblRacer2SM.TabIndex = 12;
            this.lblRacer2SM.Text = "racer 2:";
            // 
            // lblRacer1SM
            // 
            this.lblRacer1SM.AutoSize = true;
            this.lblRacer1SM.Location = new System.Drawing.Point(7, 379);
            this.lblRacer1SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRacer1SM.Name = "lblRacer1SM";
            this.lblRacer1SM.Size = new System.Drawing.Size(43, 13);
            this.lblRacer1SM.TabIndex = 11;
            this.lblRacer1SM.Text = "racer 1:";
            // 
            // pbxRacer4TrailSM
            // 
            this.pbxRacer4TrailSM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer4TrailSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer4TrailSM.Image")));
            this.pbxRacer4TrailSM.Location = new System.Drawing.Point(4, 202);
            this.pbxRacer4TrailSM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer4TrailSM.Name = "pbxRacer4TrailSM";
            this.pbxRacer4TrailSM.Size = new System.Drawing.Size(8, 61);
            this.pbxRacer4TrailSM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer4TrailSM.TabIndex = 24;
            this.pbxRacer4TrailSM.TabStop = false;
            // 
            // pbxRacer3TrailSM
            // 
            this.pbxRacer3TrailSM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer3TrailSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer3TrailSM.Image")));
            this.pbxRacer3TrailSM.Location = new System.Drawing.Point(4, 136);
            this.pbxRacer3TrailSM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer3TrailSM.Name = "pbxRacer3TrailSM";
            this.pbxRacer3TrailSM.Size = new System.Drawing.Size(8, 61);
            this.pbxRacer3TrailSM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer3TrailSM.TabIndex = 24;
            this.pbxRacer3TrailSM.TabStop = false;
            // 
            // pbxRacer1TrailSM
            // 
            this.pbxRacer1TrailSM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer1TrailSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer1TrailSM.Image")));
            this.pbxRacer1TrailSM.Location = new System.Drawing.Point(4, 5);
            this.pbxRacer1TrailSM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer1TrailSM.Name = "pbxRacer1TrailSM";
            this.pbxRacer1TrailSM.Size = new System.Drawing.Size(8, 61);
            this.pbxRacer1TrailSM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer1TrailSM.TabIndex = 24;
            this.pbxRacer1TrailSM.TabStop = false;
            // 
            // pbxRacer2TrailSM
            // 
            this.pbxRacer2TrailSM.BackColor = System.Drawing.Color.Black;
            this.pbxRacer2TrailSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxRacer2TrailSM.Image")));
            this.pbxRacer2TrailSM.Location = new System.Drawing.Point(4, 71);
            this.pbxRacer2TrailSM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxRacer2TrailSM.Name = "pbxRacer2TrailSM";
            this.pbxRacer2TrailSM.Size = new System.Drawing.Size(8, 61);
            this.pbxRacer2TrailSM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRacer2TrailSM.TabIndex = 24;
            this.pbxRacer2TrailSM.TabStop = false;
            // 
            // tbpMainSettingsSM
            // 
            this.tbpMainSettingsSM.Controls.Add(this.rtbSettingsSM);
            this.tbpMainSettingsSM.Controls.Add(this.txbRacerName3SM);
            this.tbpMainSettingsSM.Controls.Add(this.txbRacerName4SM);
            this.tbpMainSettingsSM.Controls.Add(this.txbRacerName2SM);
            this.tbpMainSettingsSM.Controls.Add(this.txbRacerName1SM);
            this.tbpMainSettingsSM.Controls.Add(this.label71);
            this.tbpMainSettingsSM.Controls.Add(this.label70);
            this.tbpMainSettingsSM.Controls.Add(this.label69);
            this.tbpMainSettingsSM.Controls.Add(this.label66);
            this.tbpMainSettingsSM.Controls.Add(this.label65);
            this.tbpMainSettingsSM.Controls.Add(this.lblStapsizeTick4SM);
            this.tbpMainSettingsSM.Controls.Add(this.lblStapsizeTick2SM);
            this.tbpMainSettingsSM.Controls.Add(this.lblStapsizeTick3SM);
            this.tbpMainSettingsSM.Controls.Add(this.lblStapsizeTick1SM);
            this.tbpMainSettingsSM.Controls.Add(this.label68);
            this.tbpMainSettingsSM.Controls.Add(this.label59);
            this.tbpMainSettingsSM.Controls.Add(this.label67);
            this.tbpMainSettingsSM.Controls.Add(this.label58);
            this.tbpMainSettingsSM.Controls.Add(this.lblEngine3SM);
            this.tbpMainSettingsSM.Controls.Add(this.lblEngine1SM);
            this.tbpMainSettingsSM.Controls.Add(this.lblEngine4SM);
            this.tbpMainSettingsSM.Controls.Add(this.lblEngine2SM);
            this.tbpMainSettingsSM.Controls.Add(this.label64);
            this.tbpMainSettingsSM.Controls.Add(this.label63);
            this.tbpMainSettingsSM.Controls.Add(this.label57);
            this.tbpMainSettingsSM.Controls.Add(this.label62);
            this.tbpMainSettingsSM.Controls.Add(this.label56);
            this.tbpMainSettingsSM.Controls.Add(this.label61);
            this.tbpMainSettingsSM.Controls.Add(this.label55);
            this.tbpMainSettingsSM.Controls.Add(this.label54);
            this.tbpMainSettingsSM.Controls.Add(this.btnSetupRacers);
            this.tbpMainSettingsSM.Controls.Add(this.btnDefaultSM);
            this.tbpMainSettingsSM.Controls.Add(this.txbMaxSpeedSM);
            this.tbpMainSettingsSM.Controls.Add(this.txbMinSpeedSM);
            this.tbpMainSettingsSM.Controls.Add(this.label53);
            this.tbpMainSettingsSM.Controls.Add(this.label50);
            this.tbpMainSettingsSM.Location = new System.Drawing.Point(4, 22);
            this.tbpMainSettingsSM.Margin = new System.Windows.Forms.Padding(2);
            this.tbpMainSettingsSM.Name = "tbpMainSettingsSM";
            this.tbpMainSettingsSM.Padding = new System.Windows.Forms.Padding(2);
            this.tbpMainSettingsSM.Size = new System.Drawing.Size(921, 490);
            this.tbpMainSettingsSM.TabIndex = 1;
            this.tbpMainSettingsSM.Text = "settings";
            this.tbpMainSettingsSM.UseVisualStyleBackColor = true;
            // 
            // rtbSettingsSM
            // 
            this.rtbSettingsSM.Location = new System.Drawing.Point(670, 4);
            this.rtbSettingsSM.Margin = new System.Windows.Forms.Padding(2);
            this.rtbSettingsSM.Name = "rtbSettingsSM";
            this.rtbSettingsSM.Size = new System.Drawing.Size(247, 203);
            this.rtbSettingsSM.TabIndex = 12;
            this.rtbSettingsSM.Text = "";
            // 
            // txbRacerName3SM
            // 
            this.txbRacerName3SM.Location = new System.Drawing.Point(86, 236);
            this.txbRacerName3SM.Margin = new System.Windows.Forms.Padding(2);
            this.txbRacerName3SM.Name = "txbRacerName3SM";
            this.txbRacerName3SM.Size = new System.Drawing.Size(76, 20);
            this.txbRacerName3SM.TabIndex = 11;
            // 
            // txbRacerName4SM
            // 
            this.txbRacerName4SM.Location = new System.Drawing.Point(86, 258);
            this.txbRacerName4SM.Margin = new System.Windows.Forms.Padding(2);
            this.txbRacerName4SM.Name = "txbRacerName4SM";
            this.txbRacerName4SM.Size = new System.Drawing.Size(76, 20);
            this.txbRacerName4SM.TabIndex = 11;
            // 
            // txbRacerName2SM
            // 
            this.txbRacerName2SM.Location = new System.Drawing.Point(86, 214);
            this.txbRacerName2SM.Margin = new System.Windows.Forms.Padding(2);
            this.txbRacerName2SM.Name = "txbRacerName2SM";
            this.txbRacerName2SM.Size = new System.Drawing.Size(76, 20);
            this.txbRacerName2SM.TabIndex = 11;
            // 
            // txbRacerName1SM
            // 
            this.txbRacerName1SM.Location = new System.Drawing.Point(86, 192);
            this.txbRacerName1SM.Margin = new System.Windows.Forms.Padding(2);
            this.txbRacerName1SM.Name = "txbRacerName1SM";
            this.txbRacerName1SM.Size = new System.Drawing.Size(76, 20);
            this.txbRacerName1SM.TabIndex = 11;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(50, 237);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(36, 13);
            this.label71.TabIndex = 10;
            this.label71.Text = "name:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(50, 260);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(36, 13);
            this.label70.TabIndex = 10;
            this.label70.Text = "name:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(50, 216);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(36, 13);
            this.label69.TabIndex = 10;
            this.label69.Text = "name:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(50, 195);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(36, 13);
            this.label66.TabIndex = 10;
            this.label66.Text = "name:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(8, 167);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(90, 20);
            this.label65.TabIndex = 9;
            this.label65.Text = "the racers";
            // 
            // lblStapsizeTick4SM
            // 
            this.lblStapsizeTick4SM.AutoSize = true;
            this.lblStapsizeTick4SM.Location = new System.Drawing.Point(332, 260);
            this.lblStapsizeTick4SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStapsizeTick4SM.Name = "lblStapsizeTick4SM";
            this.lblStapsizeTick4SM.Size = new System.Drawing.Size(16, 13);
            this.lblStapsizeTick4SM.TabIndex = 8;
            this.lblStapsizeTick4SM.Text = "---";
            // 
            // lblStapsizeTick2SM
            // 
            this.lblStapsizeTick2SM.AutoSize = true;
            this.lblStapsizeTick2SM.Location = new System.Drawing.Point(332, 216);
            this.lblStapsizeTick2SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStapsizeTick2SM.Name = "lblStapsizeTick2SM";
            this.lblStapsizeTick2SM.Size = new System.Drawing.Size(16, 13);
            this.lblStapsizeTick2SM.TabIndex = 8;
            this.lblStapsizeTick2SM.Text = "---";
            // 
            // lblStapsizeTick3SM
            // 
            this.lblStapsizeTick3SM.AutoSize = true;
            this.lblStapsizeTick3SM.Location = new System.Drawing.Point(332, 237);
            this.lblStapsizeTick3SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStapsizeTick3SM.Name = "lblStapsizeTick3SM";
            this.lblStapsizeTick3SM.Size = new System.Drawing.Size(16, 13);
            this.lblStapsizeTick3SM.TabIndex = 8;
            this.lblStapsizeTick3SM.Text = "---";
            // 
            // lblStapsizeTick1SM
            // 
            this.lblStapsizeTick1SM.AutoSize = true;
            this.lblStapsizeTick1SM.Location = new System.Drawing.Point(332, 195);
            this.lblStapsizeTick1SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStapsizeTick1SM.Name = "lblStapsizeTick1SM";
            this.lblStapsizeTick1SM.Size = new System.Drawing.Size(16, 13);
            this.lblStapsizeTick1SM.TabIndex = 8;
            this.lblStapsizeTick1SM.Text = "---";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(247, 260);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(86, 13);
            this.label68.TabIndex = 7;
            this.label68.Text = "stapsize per tick:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(247, 216);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(86, 13);
            this.label59.TabIndex = 7;
            this.label59.Text = "stapsize per tick:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(247, 238);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(86, 13);
            this.label67.TabIndex = 7;
            this.label67.Text = "stapsize per tick:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(247, 194);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(86, 13);
            this.label58.TabIndex = 7;
            this.label58.Text = "stapsize per tick:";
            // 
            // lblEngine3SM
            // 
            this.lblEngine3SM.AutoSize = true;
            this.lblEngine3SM.Location = new System.Drawing.Point(212, 239);
            this.lblEngine3SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEngine3SM.Name = "lblEngine3SM";
            this.lblEngine3SM.Size = new System.Drawing.Size(16, 13);
            this.lblEngine3SM.TabIndex = 6;
            this.lblEngine3SM.Text = "---";
            // 
            // lblEngine1SM
            // 
            this.lblEngine1SM.AutoSize = true;
            this.lblEngine1SM.Location = new System.Drawing.Point(212, 195);
            this.lblEngine1SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEngine1SM.Name = "lblEngine1SM";
            this.lblEngine1SM.Size = new System.Drawing.Size(16, 13);
            this.lblEngine1SM.TabIndex = 6;
            this.lblEngine1SM.Text = "---";
            // 
            // lblEngine4SM
            // 
            this.lblEngine4SM.AutoSize = true;
            this.lblEngine4SM.Location = new System.Drawing.Point(212, 260);
            this.lblEngine4SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEngine4SM.Name = "lblEngine4SM";
            this.lblEngine4SM.Size = new System.Drawing.Size(16, 13);
            this.lblEngine4SM.TabIndex = 6;
            this.lblEngine4SM.Text = "---";
            // 
            // lblEngine2SM
            // 
            this.lblEngine2SM.AutoSize = true;
            this.lblEngine2SM.Location = new System.Drawing.Point(212, 216);
            this.lblEngine2SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEngine2SM.Name = "lblEngine2SM";
            this.lblEngine2SM.Size = new System.Drawing.Size(16, 13);
            this.lblEngine2SM.TabIndex = 6;
            this.lblEngine2SM.Text = "---";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(169, 260);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(42, 13);
            this.label64.TabIndex = 5;
            this.label64.Text = "engine:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(169, 239);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(42, 13);
            this.label63.TabIndex = 5;
            this.label63.Text = "engine:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(169, 216);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(42, 13);
            this.label57.TabIndex = 5;
            this.label57.Text = "engine:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(7, 260);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(43, 13);
            this.label62.TabIndex = 4;
            this.label62.Text = "racer 4:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(169, 195);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(42, 13);
            this.label56.TabIndex = 5;
            this.label56.Text = "engine:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(7, 239);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(43, 13);
            this.label61.TabIndex = 3;
            this.label61.Text = "racer 3:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(7, 216);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(43, 13);
            this.label55.TabIndex = 4;
            this.label55.Text = "racer 2:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(7, 195);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(43, 13);
            this.label54.TabIndex = 3;
            this.label54.Text = "racer 1:";
            // 
            // btnSetupRacers
            // 
            this.btnSetupRacers.Location = new System.Drawing.Point(6, 285);
            this.btnSetupRacers.Margin = new System.Windows.Forms.Padding(2);
            this.btnSetupRacers.Name = "btnSetupRacers";
            this.btnSetupRacers.Size = new System.Drawing.Size(75, 19);
            this.btnSetupRacers.TabIndex = 2;
            this.btnSetupRacers.Text = "setup racers";
            this.btnSetupRacers.UseVisualStyleBackColor = true;
            this.btnSetupRacers.Click += new System.EventHandler(this.btnSetupRacers_Click);
            // 
            // btnDefaultSM
            // 
            this.btnDefaultSM.Location = new System.Drawing.Point(76, 59);
            this.btnDefaultSM.Margin = new System.Windows.Forms.Padding(2);
            this.btnDefaultSM.Name = "btnDefaultSM";
            this.btnDefaultSM.Size = new System.Drawing.Size(75, 19);
            this.btnDefaultSM.TabIndex = 2;
            this.btnDefaultSM.Text = "Default";
            this.btnDefaultSM.UseVisualStyleBackColor = true;
            this.btnDefaultSM.Click += new System.EventHandler(this.btnDefaultSM_Click);
            // 
            // txbMaxSpeedSM
            // 
            this.txbMaxSpeedSM.Location = new System.Drawing.Point(76, 37);
            this.txbMaxSpeedSM.Margin = new System.Windows.Forms.Padding(2);
            this.txbMaxSpeedSM.Name = "txbMaxSpeedSM";
            this.txbMaxSpeedSM.Size = new System.Drawing.Size(76, 20);
            this.txbMaxSpeedSM.TabIndex = 1;
            // 
            // txbMinSpeedSM
            // 
            this.txbMinSpeedSM.Location = new System.Drawing.Point(76, 16);
            this.txbMinSpeedSM.Margin = new System.Windows.Forms.Padding(2);
            this.txbMinSpeedSM.Name = "txbMinSpeedSM";
            this.txbMinSpeedSM.Size = new System.Drawing.Size(76, 20);
            this.txbMinSpeedSM.TabIndex = 1;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 39);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(60, 13);
            this.label53.TabIndex = 0;
            this.label53.Text = "maxSpeed:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(9, 19);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(57, 13);
            this.label50.TabIndex = 0;
            this.label50.Text = "minSpeed:";
            // 
            // tbpMainCasinoSM
            // 
            this.tbpMainCasinoSM.Controls.Add(this.pictureBox1);
            this.tbpMainCasinoSM.Controls.Add(this.pictureBox2);
            this.tbpMainCasinoSM.Controls.Add(this.pictureBox3);
            this.tbpMainCasinoSM.Controls.Add(this.pictureBox4);
            this.tbpMainCasinoSM.Controls.Add(this.rtbCasinoSM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette34SM);
            this.tbpMainCasinoSM.Controls.Add(this.gbxrouletteSM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette0SM);
            this.tbpMainCasinoSM.Controls.Add(this.tbxRouletteSM);
            this.tbpMainCasinoSM.Controls.Add(this.label12);
            this.tbpMainCasinoSM.Controls.Add(this.btnRouletteGoSM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette36SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette35SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette33SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette32SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette31SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette30SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette26SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette27SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette29SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette28SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette25SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette23SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette22SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette24SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette20SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette17SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette16SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette19SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette18SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette15SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette12SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette10SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette14SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette11SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette9SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette13SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette8SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette7SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette6SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette5SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette4SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette3SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette2SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette1SM);
            this.tbpMainCasinoSM.Controls.Add(this.lblBetsLostSM);
            this.tbpMainCasinoSM.Controls.Add(this.label13);
            this.tbpMainCasinoSM.Controls.Add(this.lblBetsWonSM);
            this.tbpMainCasinoSM.Controls.Add(this.label11);
            this.tbpMainCasinoSM.Controls.Add(this.lblBettingOnSM);
            this.tbpMainCasinoSM.Controls.Add(this.label10);
            this.tbpMainCasinoSM.Controls.Add(this.label9);
            this.tbpMainCasinoSM.Controls.Add(this.label8);
            this.tbpMainCasinoSM.Controls.Add(this.label7);
            this.tbpMainCasinoSM.Controls.Add(this.label6);
            this.tbpMainCasinoSM.Controls.Add(this.tbxBet3SM);
            this.tbpMainCasinoSM.Controls.Add(this.tbxBet4SM);
            this.tbpMainCasinoSM.Controls.Add(this.tbxBet1SM);
            this.tbpMainCasinoSM.Controls.Add(this.tbxBet2SM);
            this.tbpMainCasinoSM.Controls.Add(this.btnBet4SM);
            this.tbpMainCasinoSM.Controls.Add(this.btnBet3SM);
            this.tbpMainCasinoSM.Controls.Add(this.btnBet2SM);
            this.tbpMainCasinoSM.Controls.Add(this.btnBet1SM);
            this.tbpMainCasinoSM.Controls.Add(this.label5);
            this.tbpMainCasinoSM.Controls.Add(this.label4);
            this.tbpMainCasinoSM.Controls.Add(this.label3);
            this.tbpMainCasinoSM.Controls.Add(this.label2);
            this.tbpMainCasinoSM.Controls.Add(this.lblCoinsSM);
            this.tbpMainCasinoSM.Controls.Add(this.label1);
            this.tbpMainCasinoSM.Controls.Add(this.lblRoulette21SM);
            this.tbpMainCasinoSM.Location = new System.Drawing.Point(4, 22);
            this.tbpMainCasinoSM.Margin = new System.Windows.Forms.Padding(2);
            this.tbpMainCasinoSM.Name = "tbpMainCasinoSM";
            this.tbpMainCasinoSM.Padding = new System.Windows.Forms.Padding(2);
            this.tbpMainCasinoSM.Size = new System.Drawing.Size(921, 490);
            this.tbpMainCasinoSM.TabIndex = 2;
            this.tbpMainCasinoSM.Text = "Casino";
            this.tbpMainCasinoSM.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(206, 238);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(82, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 164;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(206, 172);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(82, 61);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 162;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Black;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(206, 107);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(82, 61);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 165;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Black;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(206, 41);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(82, 61);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 163;
            this.pictureBox4.TabStop = false;
            // 
            // rtbCasinoSM
            // 
            this.rtbCasinoSM.Location = new System.Drawing.Point(751, 18);
            this.rtbCasinoSM.Name = "rtbCasinoSM";
            this.rtbCasinoSM.Size = new System.Drawing.Size(148, 136);
            this.rtbCasinoSM.TabIndex = 161;
            this.rtbCasinoSM.Text = "";
            // 
            // lblRoulette34SM
            // 
            this.lblRoulette34SM.AutoSize = true;
            this.lblRoulette34SM.Location = new System.Drawing.Point(529, 24);
            this.lblRoulette34SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette34SM.Name = "lblRoulette34SM";
            this.lblRoulette34SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette34SM.TabIndex = 58;
            this.lblRoulette34SM.Text = "34";
            // 
            // gbxrouletteSM
            // 
            this.gbxrouletteSM.Controls.Add(this.panel9);
            this.gbxrouletteSM.Controls.Add(this.panel1);
            this.gbxrouletteSM.Controls.Add(this.panel61);
            this.gbxrouletteSM.Controls.Add(this.panel2);
            this.gbxrouletteSM.Controls.Add(this.panel19);
            this.gbxrouletteSM.Controls.Add(this.panel3);
            this.gbxrouletteSM.Controls.Add(this.panel20);
            this.gbxrouletteSM.Controls.Add(this.panel6);
            this.gbxrouletteSM.Controls.Add(this.panel21);
            this.gbxrouletteSM.Controls.Add(this.panel8);
            this.gbxrouletteSM.Controls.Add(this.panel22);
            this.gbxrouletteSM.Controls.Add(this.panel5);
            this.gbxrouletteSM.Controls.Add(this.panel23);
            this.gbxrouletteSM.Controls.Add(this.panel4);
            this.gbxrouletteSM.Controls.Add(this.panel24);
            this.gbxrouletteSM.Controls.Add(this.panel7);
            this.gbxrouletteSM.Controls.Add(this.panel25);
            this.gbxrouletteSM.Controls.Add(this.panel18);
            this.gbxrouletteSM.Controls.Add(this.panel26);
            this.gbxrouletteSM.Controls.Add(this.panel17);
            this.gbxrouletteSM.Controls.Add(this.panel27);
            this.gbxrouletteSM.Controls.Add(this.panel16);
            this.gbxrouletteSM.Controls.Add(this.panel28);
            this.gbxrouletteSM.Controls.Add(this.panel15);
            this.gbxrouletteSM.Controls.Add(this.panel29);
            this.gbxrouletteSM.Controls.Add(this.panel14);
            this.gbxrouletteSM.Controls.Add(this.panel30);
            this.gbxrouletteSM.Controls.Add(this.panel13);
            this.gbxrouletteSM.Controls.Add(this.panel31);
            this.gbxrouletteSM.Controls.Add(this.panel12);
            this.gbxrouletteSM.Controls.Add(this.panel32);
            this.gbxrouletteSM.Controls.Add(this.panel11);
            this.gbxrouletteSM.Controls.Add(this.panel33);
            this.gbxrouletteSM.Controls.Add(this.panel10);
            this.gbxrouletteSM.Controls.Add(this.panel34);
            this.gbxrouletteSM.Controls.Add(this.panel36);
            this.gbxrouletteSM.Controls.Add(this.panel35);
            this.gbxrouletteSM.Location = new System.Drawing.Point(427, 233);
            this.gbxrouletteSM.Margin = new System.Windows.Forms.Padding(2);
            this.gbxrouletteSM.Name = "gbxrouletteSM";
            this.gbxrouletteSM.Padding = new System.Windows.Forms.Padding(2);
            this.gbxrouletteSM.Size = new System.Drawing.Size(304, 91);
            this.gbxrouletteSM.TabIndex = 160;
            this.gbxrouletteSM.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.rbnRoulette7SM);
            this.panel9.Controls.Add(this.label22);
            this.panel9.Location = new System.Drawing.Point(76, 13);
            this.panel9.Margin = new System.Windows.Forms.Padding(2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(23, 25);
            this.panel9.TabIndex = 127;
            // 
            // rbnRoulette7SM
            // 
            this.rbnRoulette7SM.AutoSize = true;
            this.rbnRoulette7SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette7SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette7SM.Name = "rbnRoulette7SM";
            this.rbnRoulette7SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette7SM.TabIndex = 24;
            this.rbnRoulette7SM.TabStop = true;
            this.rbnRoulette7SM.UseVisualStyleBackColor = true;
            this.rbnRoulette7SM.CheckedChanged += new System.EventHandler(this.rbnRoulette7SM_CheckedChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 11);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(13, 13);
            this.label22.TabIndex = 90;
            this.label22.Text = "7";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.rbnRoulette1SM);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Location = new System.Drawing.Point(32, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(23, 25);
            this.panel1.TabIndex = 121;
            // 
            // rbnRoulette1SM
            // 
            this.rbnRoulette1SM.AutoSize = true;
            this.rbnRoulette1SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette1SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette1SM.Name = "rbnRoulette1SM";
            this.rbnRoulette1SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette1SM.TabIndex = 24;
            this.rbnRoulette1SM.TabStop = true;
            this.rbnRoulette1SM.UseVisualStyleBackColor = true;
            this.rbnRoulette1SM.CheckedChanged += new System.EventHandler(this.rbnRoulette1SM_CheckedChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 11);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 90;
            this.label14.Text = "1";
            // 
            // panel61
            // 
            this.panel61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel61.Controls.Add(this.label52);
            this.panel61.Controls.Add(this.rbnRoulette0SM);
            this.panel61.Controls.Add(this.label51);
            this.panel61.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel61.Location = new System.Drawing.Point(10, 13);
            this.panel61.Margin = new System.Windows.Forms.Padding(2);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(23, 72);
            this.panel61.TabIndex = 157;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(5, 8);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(13, 13);
            this.label52.TabIndex = 160;
            this.label52.Text = "0";
            // 
            // rbnRoulette0SM
            // 
            this.rbnRoulette0SM.AutoSize = true;
            this.rbnRoulette0SM.Location = new System.Drawing.Point(4, 28);
            this.rbnRoulette0SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette0SM.Name = "rbnRoulette0SM";
            this.rbnRoulette0SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette0SM.TabIndex = 158;
            this.rbnRoulette0SM.TabStop = true;
            this.rbnRoulette0SM.UseVisualStyleBackColor = true;
            this.rbnRoulette0SM.CheckedChanged += new System.EventHandler(this.rbnRoulette0SM_CheckedChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(5, 49);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(13, 13);
            this.label51.TabIndex = 159;
            this.label51.Text = "0";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.rbnRoulette2SM);
            this.panel2.Location = new System.Drawing.Point(32, 37);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(23, 25);
            this.panel2.TabIndex = 122;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 11);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 90;
            this.label15.Text = "2";
            // 
            // rbnRoulette2SM
            // 
            this.rbnRoulette2SM.AutoSize = true;
            this.rbnRoulette2SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette2SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette2SM.Name = "rbnRoulette2SM";
            this.rbnRoulette2SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette2SM.TabIndex = 24;
            this.rbnRoulette2SM.TabStop = true;
            this.rbnRoulette2SM.UseVisualStyleBackColor = true;
            this.rbnRoulette2SM.CheckedChanged += new System.EventHandler(this.rbnRoulette2SM_CheckedChanged);
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.label32);
            this.panel19.Controls.Add(this.rbnRoulette36SM);
            this.panel19.Location = new System.Drawing.Point(270, 60);
            this.panel19.Margin = new System.Windows.Forms.Padding(2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(23, 25);
            this.panel19.TabIndex = 156;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(7, 11);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 13);
            this.label32.TabIndex = 90;
            this.label32.Text = "36";
            // 
            // rbnRoulette36SM
            // 
            this.rbnRoulette36SM.AutoSize = true;
            this.rbnRoulette36SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette36SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette36SM.Name = "rbnRoulette36SM";
            this.rbnRoulette36SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette36SM.TabIndex = 24;
            this.rbnRoulette36SM.TabStop = true;
            this.rbnRoulette36SM.UseVisualStyleBackColor = true;
            this.rbnRoulette36SM.CheckedChanged += new System.EventHandler(this.rbnRoulette36SM_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.rbnRoulette3SM);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Location = new System.Drawing.Point(32, 60);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(23, 25);
            this.panel3.TabIndex = 123;
            // 
            // rbnRoulette3SM
            // 
            this.rbnRoulette3SM.AutoSize = true;
            this.rbnRoulette3SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette3SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette3SM.Name = "rbnRoulette3SM";
            this.rbnRoulette3SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette3SM.TabIndex = 24;
            this.rbnRoulette3SM.TabStop = true;
            this.rbnRoulette3SM.UseVisualStyleBackColor = true;
            this.rbnRoulette3SM.CheckedChanged += new System.EventHandler(this.rbnRoulette3SM_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 11);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 90;
            this.label16.Text = "3";
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.label33);
            this.panel20.Controls.Add(this.rbnRoulette33SM);
            this.panel20.Location = new System.Drawing.Point(248, 60);
            this.panel20.Margin = new System.Windows.Forms.Padding(2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(23, 25);
            this.panel20.TabIndex = 153;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(7, 11);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(19, 13);
            this.label33.TabIndex = 90;
            this.label33.Text = "33";
            // 
            // rbnRoulette33SM
            // 
            this.rbnRoulette33SM.AutoSize = true;
            this.rbnRoulette33SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette33SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette33SM.Name = "rbnRoulette33SM";
            this.rbnRoulette33SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette33SM.TabIndex = 24;
            this.rbnRoulette33SM.TabStop = true;
            this.rbnRoulette33SM.UseVisualStyleBackColor = true;
            this.rbnRoulette33SM.CheckedChanged += new System.EventHandler(this.rbnRoulette33SM_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.rbnRoulette4SM);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Location = new System.Drawing.Point(54, 13);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(23, 25);
            this.panel6.TabIndex = 124;
            // 
            // rbnRoulette4SM
            // 
            this.rbnRoulette4SM.AutoSize = true;
            this.rbnRoulette4SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette4SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette4SM.Name = "rbnRoulette4SM";
            this.rbnRoulette4SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette4SM.TabIndex = 24;
            this.rbnRoulette4SM.TabStop = true;
            this.rbnRoulette4SM.UseVisualStyleBackColor = true;
            this.rbnRoulette4SM.CheckedChanged += new System.EventHandler(this.rbnRoulette4SM_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 11);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(13, 13);
            this.label19.TabIndex = 90;
            this.label19.Text = "4";
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.label34);
            this.panel21.Controls.Add(this.rbnRoulette32SM);
            this.panel21.Location = new System.Drawing.Point(248, 37);
            this.panel21.Margin = new System.Windows.Forms.Padding(2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(23, 25);
            this.panel21.TabIndex = 152;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(7, 11);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 13);
            this.label34.TabIndex = 90;
            this.label34.Text = "32";
            // 
            // rbnRoulette32SM
            // 
            this.rbnRoulette32SM.AutoSize = true;
            this.rbnRoulette32SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette32SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette32SM.Name = "rbnRoulette32SM";
            this.rbnRoulette32SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette32SM.TabIndex = 24;
            this.rbnRoulette32SM.TabStop = true;
            this.rbnRoulette32SM.UseVisualStyleBackColor = true;
            this.rbnRoulette32SM.CheckedChanged += new System.EventHandler(this.rbnRoulette32SM_CheckedChanged);
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label21);
            this.panel8.Controls.Add(this.rbnRoulette8SM);
            this.panel8.Location = new System.Drawing.Point(76, 37);
            this.panel8.Margin = new System.Windows.Forms.Padding(2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(23, 25);
            this.panel8.TabIndex = 128;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 11);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 13);
            this.label21.TabIndex = 90;
            this.label21.Text = "8";
            // 
            // rbnRoulette8SM
            // 
            this.rbnRoulette8SM.AutoSize = true;
            this.rbnRoulette8SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette8SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette8SM.Name = "rbnRoulette8SM";
            this.rbnRoulette8SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette8SM.TabIndex = 24;
            this.rbnRoulette8SM.TabStop = true;
            this.rbnRoulette8SM.UseVisualStyleBackColor = true;
            this.rbnRoulette8SM.CheckedChanged += new System.EventHandler(this.rbnRoulette8SM_CheckedChanged);
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.label35);
            this.panel22.Controls.Add(this.rbnRoulette35SM);
            this.panel22.Location = new System.Drawing.Point(270, 37);
            this.panel22.Margin = new System.Windows.Forms.Padding(2);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(23, 25);
            this.panel22.TabIndex = 155;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(7, 11);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(19, 13);
            this.label35.TabIndex = 90;
            this.label35.Text = "35";
            // 
            // rbnRoulette35SM
            // 
            this.rbnRoulette35SM.AutoSize = true;
            this.rbnRoulette35SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette35SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette35SM.Name = "rbnRoulette35SM";
            this.rbnRoulette35SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette35SM.TabIndex = 24;
            this.rbnRoulette35SM.TabStop = true;
            this.rbnRoulette35SM.UseVisualStyleBackColor = true;
            this.rbnRoulette35SM.CheckedChanged += new System.EventHandler(this.rbnRoulette35SM_CheckedChanged);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.rbnRoulette5SM);
            this.panel5.Location = new System.Drawing.Point(54, 37);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(23, 25);
            this.panel5.TabIndex = 125;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 11);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 90;
            this.label18.Text = "5";
            // 
            // rbnRoulette5SM
            // 
            this.rbnRoulette5SM.AutoSize = true;
            this.rbnRoulette5SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette5SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette5SM.Name = "rbnRoulette5SM";
            this.rbnRoulette5SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette5SM.TabIndex = 24;
            this.rbnRoulette5SM.TabStop = true;
            this.rbnRoulette5SM.UseVisualStyleBackColor = true;
            this.rbnRoulette5SM.CheckedChanged += new System.EventHandler(this.rbnRoulette5SM_CheckedChanged);
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.label36);
            this.panel23.Controls.Add(this.rbnRoulette34SM);
            this.panel23.Location = new System.Drawing.Point(270, 13);
            this.panel23.Margin = new System.Windows.Forms.Padding(2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(23, 25);
            this.panel23.TabIndex = 154;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(7, 11);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(19, 13);
            this.label36.TabIndex = 90;
            this.label36.Text = "34";
            // 
            // rbnRoulette34SM
            // 
            this.rbnRoulette34SM.AutoSize = true;
            this.rbnRoulette34SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette34SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette34SM.Name = "rbnRoulette34SM";
            this.rbnRoulette34SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette34SM.TabIndex = 24;
            this.rbnRoulette34SM.TabStop = true;
            this.rbnRoulette34SM.UseVisualStyleBackColor = true;
            this.rbnRoulette34SM.CheckedChanged += new System.EventHandler(this.rbnRoulette34SM_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.rbnRoulette6SM);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Location = new System.Drawing.Point(54, 60);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(23, 25);
            this.panel4.TabIndex = 126;
            // 
            // rbnRoulette6SM
            // 
            this.rbnRoulette6SM.AutoSize = true;
            this.rbnRoulette6SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette6SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette6SM.Name = "rbnRoulette6SM";
            this.rbnRoulette6SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette6SM.TabIndex = 24;
            this.rbnRoulette6SM.TabStop = true;
            this.rbnRoulette6SM.UseVisualStyleBackColor = true;
            this.rbnRoulette6SM.CheckedChanged += new System.EventHandler(this.rbnRoulette6SM_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 11);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 13);
            this.label17.TabIndex = 90;
            this.label17.Text = "6";
            // 
            // panel24
            // 
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.label37);
            this.panel24.Controls.Add(this.rbnRoulette31SM);
            this.panel24.Location = new System.Drawing.Point(248, 13);
            this.panel24.Margin = new System.Windows.Forms.Padding(2);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(23, 25);
            this.panel24.TabIndex = 151;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(7, 11);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(19, 13);
            this.label37.TabIndex = 90;
            this.label37.Text = "31";
            // 
            // rbnRoulette31SM
            // 
            this.rbnRoulette31SM.AutoSize = true;
            this.rbnRoulette31SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette31SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette31SM.Name = "rbnRoulette31SM";
            this.rbnRoulette31SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette31SM.TabIndex = 24;
            this.rbnRoulette31SM.TabStop = true;
            this.rbnRoulette31SM.UseVisualStyleBackColor = true;
            this.rbnRoulette31SM.CheckedChanged += new System.EventHandler(this.rbnRoulette31SM_CheckedChanged);
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.rbnRoulette9SM);
            this.panel7.Controls.Add(this.label20);
            this.panel7.Location = new System.Drawing.Point(76, 60);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(23, 25);
            this.panel7.TabIndex = 129;
            // 
            // rbnRoulette9SM
            // 
            this.rbnRoulette9SM.AutoSize = true;
            this.rbnRoulette9SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette9SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette9SM.Name = "rbnRoulette9SM";
            this.rbnRoulette9SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette9SM.TabIndex = 24;
            this.rbnRoulette9SM.TabStop = true;
            this.rbnRoulette9SM.UseVisualStyleBackColor = true;
            this.rbnRoulette9SM.CheckedChanged += new System.EventHandler(this.rbnRoulette9SM_CheckedChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 11);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 13);
            this.label20.TabIndex = 90;
            this.label20.Text = "9";
            // 
            // panel25
            // 
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.label38);
            this.panel25.Controls.Add(this.rbnRoulette30SM);
            this.panel25.Location = new System.Drawing.Point(226, 60);
            this.panel25.Margin = new System.Windows.Forms.Padding(2);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(23, 25);
            this.panel25.TabIndex = 150;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(7, 11);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(19, 13);
            this.label38.TabIndex = 90;
            this.label38.Text = "30";
            // 
            // rbnRoulette30SM
            // 
            this.rbnRoulette30SM.AutoSize = true;
            this.rbnRoulette30SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette30SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette30SM.Name = "rbnRoulette30SM";
            this.rbnRoulette30SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette30SM.TabIndex = 24;
            this.rbnRoulette30SM.TabStop = true;
            this.rbnRoulette30SM.UseVisualStyleBackColor = true;
            this.rbnRoulette30SM.CheckedChanged += new System.EventHandler(this.rbnRoulette30SM_CheckedChanged);
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.label31);
            this.panel18.Controls.Add(this.rbnRoulette10SM);
            this.panel18.Location = new System.Drawing.Point(98, 13);
            this.panel18.Margin = new System.Windows.Forms.Padding(2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(23, 25);
            this.panel18.TabIndex = 130;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(7, 11);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 13);
            this.label31.TabIndex = 90;
            this.label31.Text = "10";
            // 
            // rbnRoulette10SM
            // 
            this.rbnRoulette10SM.AutoSize = true;
            this.rbnRoulette10SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette10SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette10SM.Name = "rbnRoulette10SM";
            this.rbnRoulette10SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette10SM.TabIndex = 24;
            this.rbnRoulette10SM.TabStop = true;
            this.rbnRoulette10SM.UseVisualStyleBackColor = true;
            this.rbnRoulette10SM.CheckedChanged += new System.EventHandler(this.rbnRoulette10SM_CheckedChanged);
            // 
            // panel26
            // 
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.label39);
            this.panel26.Controls.Add(this.rbnRoulette29SM);
            this.panel26.Location = new System.Drawing.Point(226, 37);
            this.panel26.Margin = new System.Windows.Forms.Padding(2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(23, 25);
            this.panel26.TabIndex = 149;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(7, 11);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(19, 13);
            this.label39.TabIndex = 90;
            this.label39.Text = "29";
            // 
            // rbnRoulette29SM
            // 
            this.rbnRoulette29SM.AutoSize = true;
            this.rbnRoulette29SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette29SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette29SM.Name = "rbnRoulette29SM";
            this.rbnRoulette29SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette29SM.TabIndex = 24;
            this.rbnRoulette29SM.TabStop = true;
            this.rbnRoulette29SM.UseVisualStyleBackColor = true;
            this.rbnRoulette29SM.CheckedChanged += new System.EventHandler(this.rbnRoulette29SM_CheckedChanged);
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.label30);
            this.panel17.Controls.Add(this.rbnRoulette11SM);
            this.panel17.Location = new System.Drawing.Point(98, 37);
            this.panel17.Margin = new System.Windows.Forms.Padding(2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(23, 25);
            this.panel17.TabIndex = 131;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(8, 11);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 13);
            this.label30.TabIndex = 90;
            this.label30.Text = "11";
            // 
            // rbnRoulette11SM
            // 
            this.rbnRoulette11SM.AutoSize = true;
            this.rbnRoulette11SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette11SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette11SM.Name = "rbnRoulette11SM";
            this.rbnRoulette11SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette11SM.TabIndex = 24;
            this.rbnRoulette11SM.TabStop = true;
            this.rbnRoulette11SM.UseVisualStyleBackColor = true;
            this.rbnRoulette11SM.CheckedChanged += new System.EventHandler(this.rbnRoulette11SM_CheckedChanged);
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.label40);
            this.panel27.Controls.Add(this.rbnRoulette28SM);
            this.panel27.Location = new System.Drawing.Point(226, 13);
            this.panel27.Margin = new System.Windows.Forms.Padding(2);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(23, 25);
            this.panel27.TabIndex = 148;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(7, 11);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(19, 13);
            this.label40.TabIndex = 90;
            this.label40.Text = "28";
            // 
            // rbnRoulette28SM
            // 
            this.rbnRoulette28SM.AutoSize = true;
            this.rbnRoulette28SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette28SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette28SM.Name = "rbnRoulette28SM";
            this.rbnRoulette28SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette28SM.TabIndex = 24;
            this.rbnRoulette28SM.TabStop = true;
            this.rbnRoulette28SM.UseVisualStyleBackColor = true;
            this.rbnRoulette28SM.CheckedChanged += new System.EventHandler(this.rbnRoulette28SM_CheckedChanged);
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.label29);
            this.panel16.Controls.Add(this.rbnRoulette12SM);
            this.panel16.Location = new System.Drawing.Point(98, 60);
            this.panel16.Margin = new System.Windows.Forms.Padding(2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(23, 25);
            this.panel16.TabIndex = 132;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(7, 11);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(19, 13);
            this.label29.TabIndex = 90;
            this.label29.Text = "12";
            // 
            // rbnRoulette12SM
            // 
            this.rbnRoulette12SM.AutoSize = true;
            this.rbnRoulette12SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette12SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette12SM.Name = "rbnRoulette12SM";
            this.rbnRoulette12SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette12SM.TabIndex = 24;
            this.rbnRoulette12SM.TabStop = true;
            this.rbnRoulette12SM.UseVisualStyleBackColor = true;
            this.rbnRoulette12SM.CheckedChanged += new System.EventHandler(this.rbnRoulette12SM_CheckedChanged);
            // 
            // panel28
            // 
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.label41);
            this.panel28.Controls.Add(this.rbnRoulette27SM);
            this.panel28.Location = new System.Drawing.Point(205, 60);
            this.panel28.Margin = new System.Windows.Forms.Padding(2);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(23, 25);
            this.panel28.TabIndex = 147;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(7, 11);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(19, 13);
            this.label41.TabIndex = 90;
            this.label41.Text = "27";
            // 
            // rbnRoulette27SM
            // 
            this.rbnRoulette27SM.AutoSize = true;
            this.rbnRoulette27SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette27SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette27SM.Name = "rbnRoulette27SM";
            this.rbnRoulette27SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette27SM.TabIndex = 24;
            this.rbnRoulette27SM.TabStop = true;
            this.rbnRoulette27SM.UseVisualStyleBackColor = true;
            this.rbnRoulette27SM.CheckedChanged += new System.EventHandler(this.rbnRoulette27SM_CheckedChanged);
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.label28);
            this.panel15.Controls.Add(this.rbnRoulette13SM);
            this.panel15.Location = new System.Drawing.Point(119, 13);
            this.panel15.Margin = new System.Windows.Forms.Padding(2);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(23, 25);
            this.panel15.TabIndex = 133;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(7, 11);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 13);
            this.label28.TabIndex = 90;
            this.label28.Text = "13";
            // 
            // rbnRoulette13SM
            // 
            this.rbnRoulette13SM.AutoSize = true;
            this.rbnRoulette13SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette13SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette13SM.Name = "rbnRoulette13SM";
            this.rbnRoulette13SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette13SM.TabIndex = 24;
            this.rbnRoulette13SM.TabStop = true;
            this.rbnRoulette13SM.UseVisualStyleBackColor = true;
            this.rbnRoulette13SM.CheckedChanged += new System.EventHandler(this.rbnRoulette13SM_CheckedChanged);
            // 
            // panel29
            // 
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.label42);
            this.panel29.Controls.Add(this.rbnRoulette24SM);
            this.panel29.Location = new System.Drawing.Point(183, 60);
            this.panel29.Margin = new System.Windows.Forms.Padding(2);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(23, 25);
            this.panel29.TabIndex = 144;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(7, 11);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(19, 13);
            this.label42.TabIndex = 90;
            this.label42.Text = "24";
            // 
            // rbnRoulette24SM
            // 
            this.rbnRoulette24SM.AutoSize = true;
            this.rbnRoulette24SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette24SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette24SM.Name = "rbnRoulette24SM";
            this.rbnRoulette24SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette24SM.TabIndex = 24;
            this.rbnRoulette24SM.TabStop = true;
            this.rbnRoulette24SM.UseVisualStyleBackColor = true;
            this.rbnRoulette24SM.CheckedChanged += new System.EventHandler(this.rbnRoulette24SM_CheckedChanged);
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.label27);
            this.panel14.Controls.Add(this.rbnRoulette16SM);
            this.panel14.Location = new System.Drawing.Point(141, 13);
            this.panel14.Margin = new System.Windows.Forms.Padding(2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(23, 25);
            this.panel14.TabIndex = 136;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(5, 11);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 13);
            this.label27.TabIndex = 90;
            this.label27.Text = "16";
            // 
            // rbnRoulette16SM
            // 
            this.rbnRoulette16SM.AutoSize = true;
            this.rbnRoulette16SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette16SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette16SM.Name = "rbnRoulette16SM";
            this.rbnRoulette16SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette16SM.TabIndex = 24;
            this.rbnRoulette16SM.TabStop = true;
            this.rbnRoulette16SM.UseVisualStyleBackColor = true;
            this.rbnRoulette16SM.CheckedChanged += new System.EventHandler(this.rbnRoulette16SM_CheckedChanged);
            // 
            // panel30
            // 
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.label43);
            this.panel30.Controls.Add(this.rbnRoulette23SM);
            this.panel30.Location = new System.Drawing.Point(183, 37);
            this.panel30.Margin = new System.Windows.Forms.Padding(2);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(23, 25);
            this.panel30.TabIndex = 143;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(7, 11);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(19, 13);
            this.label43.TabIndex = 90;
            this.label43.Text = "23";
            // 
            // rbnRoulette23SM
            // 
            this.rbnRoulette23SM.AutoSize = true;
            this.rbnRoulette23SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette23SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette23SM.Name = "rbnRoulette23SM";
            this.rbnRoulette23SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette23SM.TabIndex = 24;
            this.rbnRoulette23SM.TabStop = true;
            this.rbnRoulette23SM.UseVisualStyleBackColor = true;
            this.rbnRoulette23SM.CheckedChanged += new System.EventHandler(this.rbnRoulette23SM_CheckedChanged);
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.label26);
            this.panel13.Controls.Add(this.rbnRoulette17SM);
            this.panel13.Location = new System.Drawing.Point(141, 37);
            this.panel13.Margin = new System.Windows.Forms.Padding(2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(23, 25);
            this.panel13.TabIndex = 137;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(5, 11);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 13);
            this.label26.TabIndex = 90;
            this.label26.Text = "17";
            // 
            // rbnRoulette17SM
            // 
            this.rbnRoulette17SM.AutoSize = true;
            this.rbnRoulette17SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette17SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette17SM.Name = "rbnRoulette17SM";
            this.rbnRoulette17SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette17SM.TabIndex = 24;
            this.rbnRoulette17SM.TabStop = true;
            this.rbnRoulette17SM.UseVisualStyleBackColor = true;
            this.rbnRoulette17SM.CheckedChanged += new System.EventHandler(this.rbnRoulette17SM_CheckedChanged);
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.label44);
            this.panel31.Controls.Add(this.rbnRoulette26SM);
            this.panel31.Location = new System.Drawing.Point(205, 37);
            this.panel31.Margin = new System.Windows.Forms.Padding(2);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(23, 25);
            this.panel31.TabIndex = 146;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(7, 11);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(19, 13);
            this.label44.TabIndex = 90;
            this.label44.Text = "26";
            // 
            // rbnRoulette26SM
            // 
            this.rbnRoulette26SM.AutoSize = true;
            this.rbnRoulette26SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette26SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette26SM.Name = "rbnRoulette26SM";
            this.rbnRoulette26SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette26SM.TabIndex = 24;
            this.rbnRoulette26SM.TabStop = true;
            this.rbnRoulette26SM.UseVisualStyleBackColor = true;
            this.rbnRoulette26SM.CheckedChanged += new System.EventHandler(this.rbnRoulette26SM_CheckedChanged);
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.label25);
            this.panel12.Controls.Add(this.rbnRoulette14SM);
            this.panel12.Location = new System.Drawing.Point(119, 37);
            this.panel12.Margin = new System.Windows.Forms.Padding(2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(23, 25);
            this.panel12.TabIndex = 134;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 11);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 13);
            this.label25.TabIndex = 90;
            this.label25.Text = "14";
            // 
            // rbnRoulette14SM
            // 
            this.rbnRoulette14SM.AutoSize = true;
            this.rbnRoulette14SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette14SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette14SM.Name = "rbnRoulette14SM";
            this.rbnRoulette14SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette14SM.TabIndex = 24;
            this.rbnRoulette14SM.TabStop = true;
            this.rbnRoulette14SM.UseVisualStyleBackColor = true;
            this.rbnRoulette14SM.CheckedChanged += new System.EventHandler(this.rbnRoulette14SM_CheckedChanged);
            // 
            // panel32
            // 
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.label45);
            this.panel32.Controls.Add(this.rbnRoulette25SM);
            this.panel32.Location = new System.Drawing.Point(205, 13);
            this.panel32.Margin = new System.Windows.Forms.Padding(2);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(23, 25);
            this.panel32.TabIndex = 145;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(7, 11);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(19, 13);
            this.label45.TabIndex = 90;
            this.label45.Text = "25";
            // 
            // rbnRoulette25SM
            // 
            this.rbnRoulette25SM.AutoSize = true;
            this.rbnRoulette25SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette25SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette25SM.Name = "rbnRoulette25SM";
            this.rbnRoulette25SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette25SM.TabIndex = 24;
            this.rbnRoulette25SM.TabStop = true;
            this.rbnRoulette25SM.UseVisualStyleBackColor = true;
            this.rbnRoulette25SM.CheckedChanged += new System.EventHandler(this.rbnRoulette25SM_CheckedChanged);
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.label24);
            this.panel11.Controls.Add(this.rbnRoulette15SM);
            this.panel11.Location = new System.Drawing.Point(119, 60);
            this.panel11.Margin = new System.Windows.Forms.Padding(2);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(23, 25);
            this.panel11.TabIndex = 135;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 11);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(19, 13);
            this.label24.TabIndex = 90;
            this.label24.Text = "15";
            // 
            // rbnRoulette15SM
            // 
            this.rbnRoulette15SM.AutoSize = true;
            this.rbnRoulette15SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette15SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette15SM.Name = "rbnRoulette15SM";
            this.rbnRoulette15SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette15SM.TabIndex = 24;
            this.rbnRoulette15SM.TabStop = true;
            this.rbnRoulette15SM.UseVisualStyleBackColor = true;
            this.rbnRoulette15SM.CheckedChanged += new System.EventHandler(this.rbnRoulette15SM_CheckedChanged);
            // 
            // panel33
            // 
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Controls.Add(this.label46);
            this.panel33.Controls.Add(this.rbnRoulette22SM);
            this.panel33.Location = new System.Drawing.Point(183, 13);
            this.panel33.Margin = new System.Windows.Forms.Padding(2);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(23, 25);
            this.panel33.TabIndex = 142;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(7, 11);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(19, 13);
            this.label46.TabIndex = 90;
            this.label46.Text = "22";
            // 
            // rbnRoulette22SM
            // 
            this.rbnRoulette22SM.AutoSize = true;
            this.rbnRoulette22SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette22SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette22SM.Name = "rbnRoulette22SM";
            this.rbnRoulette22SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette22SM.TabIndex = 24;
            this.rbnRoulette22SM.TabStop = true;
            this.rbnRoulette22SM.UseVisualStyleBackColor = true;
            this.rbnRoulette22SM.CheckedChanged += new System.EventHandler(this.rbnRoulette22SM_CheckedChanged);
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label23);
            this.panel10.Controls.Add(this.rbnRoulette18SM);
            this.panel10.Location = new System.Drawing.Point(141, 60);
            this.panel10.Margin = new System.Windows.Forms.Padding(2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(23, 25);
            this.panel10.TabIndex = 138;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(5, 11);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(19, 13);
            this.label23.TabIndex = 90;
            this.label23.Text = "18";
            // 
            // rbnRoulette18SM
            // 
            this.rbnRoulette18SM.AutoSize = true;
            this.rbnRoulette18SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette18SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette18SM.Name = "rbnRoulette18SM";
            this.rbnRoulette18SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette18SM.TabIndex = 24;
            this.rbnRoulette18SM.TabStop = true;
            this.rbnRoulette18SM.UseVisualStyleBackColor = true;
            this.rbnRoulette18SM.CheckedChanged += new System.EventHandler(this.rbnRoulette18SM_CheckedChanged);
            // 
            // panel34
            // 
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.label47);
            this.panel34.Controls.Add(this.rbnRoulette21SM);
            this.panel34.Location = new System.Drawing.Point(161, 60);
            this.panel34.Margin = new System.Windows.Forms.Padding(2);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(23, 25);
            this.panel34.TabIndex = 141;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(7, 11);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(19, 13);
            this.label47.TabIndex = 90;
            this.label47.Text = "21";
            // 
            // rbnRoulette21SM
            // 
            this.rbnRoulette21SM.AutoSize = true;
            this.rbnRoulette21SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette21SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette21SM.Name = "rbnRoulette21SM";
            this.rbnRoulette21SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette21SM.TabIndex = 24;
            this.rbnRoulette21SM.TabStop = true;
            this.rbnRoulette21SM.UseVisualStyleBackColor = true;
            this.rbnRoulette21SM.CheckedChanged += new System.EventHandler(this.rbnRoulette21SM_CheckedChanged);
            // 
            // panel36
            // 
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.label49);
            this.panel36.Controls.Add(this.rbnRoulette19SM);
            this.panel36.Location = new System.Drawing.Point(161, 13);
            this.panel36.Margin = new System.Windows.Forms.Padding(2);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(23, 25);
            this.panel36.TabIndex = 139;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(7, 11);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(19, 13);
            this.label49.TabIndex = 90;
            this.label49.Text = "19";
            // 
            // rbnRoulette19SM
            // 
            this.rbnRoulette19SM.AutoSize = true;
            this.rbnRoulette19SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette19SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette19SM.Name = "rbnRoulette19SM";
            this.rbnRoulette19SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette19SM.TabIndex = 24;
            this.rbnRoulette19SM.TabStop = true;
            this.rbnRoulette19SM.UseVisualStyleBackColor = true;
            this.rbnRoulette19SM.CheckedChanged += new System.EventHandler(this.rbnRoulette19SM_CheckedChanged);
            // 
            // panel35
            // 
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.label48);
            this.panel35.Controls.Add(this.rbnRoulette20SM);
            this.panel35.Location = new System.Drawing.Point(161, 37);
            this.panel35.Margin = new System.Windows.Forms.Padding(2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(23, 25);
            this.panel35.TabIndex = 140;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(7, 11);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(19, 13);
            this.label48.TabIndex = 90;
            this.label48.Text = "20";
            // 
            // rbnRoulette20SM
            // 
            this.rbnRoulette20SM.AutoSize = true;
            this.rbnRoulette20SM.Location = new System.Drawing.Point(2, 2);
            this.rbnRoulette20SM.Margin = new System.Windows.Forms.Padding(2);
            this.rbnRoulette20SM.Name = "rbnRoulette20SM";
            this.rbnRoulette20SM.Size = new System.Drawing.Size(14, 13);
            this.rbnRoulette20SM.TabIndex = 24;
            this.rbnRoulette20SM.TabStop = true;
            this.rbnRoulette20SM.UseVisualStyleBackColor = true;
            this.rbnRoulette20SM.CheckedChanged += new System.EventHandler(this.rbnRoulette20SM_CheckedChanged);
            // 
            // lblRoulette0SM
            // 
            this.lblRoulette0SM.AutoSize = true;
            this.lblRoulette0SM.Location = new System.Drawing.Point(571, 7);
            this.lblRoulette0SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette0SM.Name = "lblRoulette0SM";
            this.lblRoulette0SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette0SM.TabIndex = 159;
            this.lblRoulette0SM.Text = "0";
            // 
            // tbxRouletteSM
            // 
            this.tbxRouletteSM.Location = new System.Drawing.Point(541, 129);
            this.tbxRouletteSM.Margin = new System.Windows.Forms.Padding(2);
            this.tbxRouletteSM.Name = "tbxRouletteSM";
            this.tbxRouletteSM.Size = new System.Drawing.Size(76, 20);
            this.tbxRouletteSM.TabIndex = 63;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(538, 112);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 62;
            this.label12.Text = "how many coins:";
            // 
            // btnRouletteGoSM
            // 
            this.btnRouletteGoSM.Location = new System.Drawing.Point(550, 91);
            this.btnRouletteGoSM.Margin = new System.Windows.Forms.Padding(2);
            this.btnRouletteGoSM.Name = "btnRouletteGoSM";
            this.btnRouletteGoSM.Size = new System.Drawing.Size(56, 19);
            this.btnRouletteGoSM.TabIndex = 61;
            this.btnRouletteGoSM.Text = "start";
            this.btnRouletteGoSM.UseVisualStyleBackColor = true;
            this.btnRouletteGoSM.Click += new System.EventHandler(this.btnRouletteGoSM_Click);
            // 
            // lblRoulette36SM
            // 
            this.lblRoulette36SM.AutoSize = true;
            this.lblRoulette36SM.Location = new System.Drawing.Point(555, 8);
            this.lblRoulette36SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette36SM.Name = "lblRoulette36SM";
            this.lblRoulette36SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette36SM.TabIndex = 60;
            this.lblRoulette36SM.Text = "36";
            // 
            // lblRoulette35SM
            // 
            this.lblRoulette35SM.AutoSize = true;
            this.lblRoulette35SM.Location = new System.Drawing.Point(541, 13);
            this.lblRoulette35SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette35SM.Name = "lblRoulette35SM";
            this.lblRoulette35SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette35SM.TabIndex = 59;
            this.lblRoulette35SM.Text = "35";
            // 
            // lblRoulette33SM
            // 
            this.lblRoulette33SM.AutoSize = true;
            this.lblRoulette33SM.Location = new System.Drawing.Point(517, 34);
            this.lblRoulette33SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette33SM.Name = "lblRoulette33SM";
            this.lblRoulette33SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette33SM.TabIndex = 57;
            this.lblRoulette33SM.Text = "33";
            // 
            // lblRoulette32SM
            // 
            this.lblRoulette32SM.AutoSize = true;
            this.lblRoulette32SM.Location = new System.Drawing.Point(508, 45);
            this.lblRoulette32SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette32SM.Name = "lblRoulette32SM";
            this.lblRoulette32SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette32SM.TabIndex = 56;
            this.lblRoulette32SM.Text = "32";
            // 
            // lblRoulette31SM
            // 
            this.lblRoulette31SM.AutoSize = true;
            this.lblRoulette31SM.Location = new System.Drawing.Point(501, 56);
            this.lblRoulette31SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette31SM.Name = "lblRoulette31SM";
            this.lblRoulette31SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette31SM.TabIndex = 55;
            this.lblRoulette31SM.Text = "31";
            // 
            // lblRoulette30SM
            // 
            this.lblRoulette30SM.AutoSize = true;
            this.lblRoulette30SM.Location = new System.Drawing.Point(493, 67);
            this.lblRoulette30SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette30SM.Name = "lblRoulette30SM";
            this.lblRoulette30SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette30SM.TabIndex = 54;
            this.lblRoulette30SM.Text = "30";
            // 
            // lblRoulette26SM
            // 
            this.lblRoulette26SM.AutoSize = true;
            this.lblRoulette26SM.Location = new System.Drawing.Point(486, 123);
            this.lblRoulette26SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette26SM.Name = "lblRoulette26SM";
            this.lblRoulette26SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette26SM.TabIndex = 53;
            this.lblRoulette26SM.Text = "26";
            // 
            // lblRoulette27SM
            // 
            this.lblRoulette27SM.AutoSize = true;
            this.lblRoulette27SM.Location = new System.Drawing.Point(481, 107);
            this.lblRoulette27SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette27SM.Name = "lblRoulette27SM";
            this.lblRoulette27SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette27SM.TabIndex = 52;
            this.lblRoulette27SM.Text = "27";
            // 
            // lblRoulette29SM
            // 
            this.lblRoulette29SM.AutoSize = true;
            this.lblRoulette29SM.Location = new System.Drawing.Point(489, 78);
            this.lblRoulette29SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette29SM.Name = "lblRoulette29SM";
            this.lblRoulette29SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette29SM.TabIndex = 51;
            this.lblRoulette29SM.Text = "29";
            // 
            // lblRoulette28SM
            // 
            this.lblRoulette28SM.AutoSize = true;
            this.lblRoulette28SM.Location = new System.Drawing.Point(483, 91);
            this.lblRoulette28SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette28SM.Name = "lblRoulette28SM";
            this.lblRoulette28SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette28SM.TabIndex = 50;
            this.lblRoulette28SM.Text = "28";
            // 
            // lblRoulette25SM
            // 
            this.lblRoulette25SM.AutoSize = true;
            this.lblRoulette25SM.Location = new System.Drawing.Point(490, 137);
            this.lblRoulette25SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette25SM.Name = "lblRoulette25SM";
            this.lblRoulette25SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette25SM.TabIndex = 49;
            this.lblRoulette25SM.Text = "25";
            // 
            // lblRoulette23SM
            // 
            this.lblRoulette23SM.AutoSize = true;
            this.lblRoulette23SM.Location = new System.Drawing.Point(506, 164);
            this.lblRoulette23SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette23SM.Name = "lblRoulette23SM";
            this.lblRoulette23SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette23SM.TabIndex = 48;
            this.lblRoulette23SM.Text = "23";
            // 
            // lblRoulette22SM
            // 
            this.lblRoulette22SM.AutoSize = true;
            this.lblRoulette22SM.Location = new System.Drawing.Point(517, 177);
            this.lblRoulette22SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette22SM.Name = "lblRoulette22SM";
            this.lblRoulette22SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette22SM.TabIndex = 47;
            this.lblRoulette22SM.Text = "22";
            // 
            // lblRoulette24SM
            // 
            this.lblRoulette24SM.AutoSize = true;
            this.lblRoulette24SM.Location = new System.Drawing.Point(497, 151);
            this.lblRoulette24SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette24SM.Name = "lblRoulette24SM";
            this.lblRoulette24SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette24SM.TabIndex = 45;
            this.lblRoulette24SM.Text = "24";
            // 
            // lblRoulette20SM
            // 
            this.lblRoulette20SM.AutoSize = true;
            this.lblRoulette20SM.Location = new System.Drawing.Point(546, 202);
            this.lblRoulette20SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette20SM.Name = "lblRoulette20SM";
            this.lblRoulette20SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette20SM.TabIndex = 44;
            this.lblRoulette20SM.Text = "20";
            // 
            // lblRoulette17SM
            // 
            this.lblRoulette17SM.AutoSize = true;
            this.lblRoulette17SM.Location = new System.Drawing.Point(589, 204);
            this.lblRoulette17SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette17SM.Name = "lblRoulette17SM";
            this.lblRoulette17SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette17SM.TabIndex = 43;
            this.lblRoulette17SM.Text = "17";
            // 
            // lblRoulette16SM
            // 
            this.lblRoulette16SM.AutoSize = true;
            this.lblRoulette16SM.Location = new System.Drawing.Point(603, 195);
            this.lblRoulette16SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette16SM.Name = "lblRoulette16SM";
            this.lblRoulette16SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette16SM.TabIndex = 42;
            this.lblRoulette16SM.Text = "16";
            // 
            // lblRoulette19SM
            // 
            this.lblRoulette19SM.AutoSize = true;
            this.lblRoulette19SM.Location = new System.Drawing.Point(559, 207);
            this.lblRoulette19SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette19SM.Name = "lblRoulette19SM";
            this.lblRoulette19SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette19SM.TabIndex = 41;
            this.lblRoulette19SM.Text = "19";
            // 
            // lblRoulette18SM
            // 
            this.lblRoulette18SM.AutoSize = true;
            this.lblRoulette18SM.Location = new System.Drawing.Point(573, 207);
            this.lblRoulette18SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette18SM.Name = "lblRoulette18SM";
            this.lblRoulette18SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette18SM.TabIndex = 40;
            this.lblRoulette18SM.Text = "18";
            // 
            // lblRoulette15SM
            // 
            this.lblRoulette15SM.AutoSize = true;
            this.lblRoulette15SM.Location = new System.Drawing.Point(615, 183);
            this.lblRoulette15SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette15SM.Name = "lblRoulette15SM";
            this.lblRoulette15SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette15SM.TabIndex = 39;
            this.lblRoulette15SM.Text = "15";
            // 
            // lblRoulette12SM
            // 
            this.lblRoulette12SM.AutoSize = true;
            this.lblRoulette12SM.Location = new System.Drawing.Point(639, 147);
            this.lblRoulette12SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette12SM.Name = "lblRoulette12SM";
            this.lblRoulette12SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette12SM.TabIndex = 38;
            this.lblRoulette12SM.Text = "12";
            // 
            // lblRoulette10SM
            // 
            this.lblRoulette10SM.AutoSize = true;
            this.lblRoulette10SM.Location = new System.Drawing.Point(649, 121);
            this.lblRoulette10SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette10SM.Name = "lblRoulette10SM";
            this.lblRoulette10SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette10SM.TabIndex = 37;
            this.lblRoulette10SM.Text = "10";
            // 
            // lblRoulette14SM
            // 
            this.lblRoulette14SM.AutoSize = true;
            this.lblRoulette14SM.Location = new System.Drawing.Point(627, 170);
            this.lblRoulette14SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette14SM.Name = "lblRoulette14SM";
            this.lblRoulette14SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette14SM.TabIndex = 36;
            this.lblRoulette14SM.Text = "14";
            // 
            // lblRoulette11SM
            // 
            this.lblRoulette11SM.AutoSize = true;
            this.lblRoulette11SM.Location = new System.Drawing.Point(645, 134);
            this.lblRoulette11SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette11SM.Name = "lblRoulette11SM";
            this.lblRoulette11SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette11SM.TabIndex = 35;
            this.lblRoulette11SM.Text = "11";
            // 
            // lblRoulette9SM
            // 
            this.lblRoulette9SM.AutoSize = true;
            this.lblRoulette9SM.Location = new System.Drawing.Point(655, 108);
            this.lblRoulette9SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette9SM.Name = "lblRoulette9SM";
            this.lblRoulette9SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette9SM.TabIndex = 34;
            this.lblRoulette9SM.Text = "9";
            // 
            // lblRoulette13SM
            // 
            this.lblRoulette13SM.AutoSize = true;
            this.lblRoulette13SM.Location = new System.Drawing.Point(633, 160);
            this.lblRoulette13SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette13SM.Name = "lblRoulette13SM";
            this.lblRoulette13SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette13SM.TabIndex = 33;
            this.lblRoulette13SM.Text = "13";
            // 
            // lblRoulette8SM
            // 
            this.lblRoulette8SM.AutoSize = true;
            this.lblRoulette8SM.Location = new System.Drawing.Point(652, 94);
            this.lblRoulette8SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette8SM.Name = "lblRoulette8SM";
            this.lblRoulette8SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette8SM.TabIndex = 32;
            this.lblRoulette8SM.Text = "8";
            // 
            // lblRoulette7SM
            // 
            this.lblRoulette7SM.AutoSize = true;
            this.lblRoulette7SM.Location = new System.Drawing.Point(647, 80);
            this.lblRoulette7SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette7SM.Name = "lblRoulette7SM";
            this.lblRoulette7SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette7SM.TabIndex = 31;
            this.lblRoulette7SM.Text = "7";
            // 
            // lblRoulette6SM
            // 
            this.lblRoulette6SM.AutoSize = true;
            this.lblRoulette6SM.Location = new System.Drawing.Point(639, 65);
            this.lblRoulette6SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette6SM.Name = "lblRoulette6SM";
            this.lblRoulette6SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette6SM.TabIndex = 30;
            this.lblRoulette6SM.Text = "6";
            // 
            // lblRoulette5SM
            // 
            this.lblRoulette5SM.AutoSize = true;
            this.lblRoulette5SM.Location = new System.Drawing.Point(629, 51);
            this.lblRoulette5SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette5SM.Name = "lblRoulette5SM";
            this.lblRoulette5SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette5SM.TabIndex = 29;
            this.lblRoulette5SM.Text = "5";
            // 
            // lblRoulette4SM
            // 
            this.lblRoulette4SM.AutoSize = true;
            this.lblRoulette4SM.Location = new System.Drawing.Point(619, 41);
            this.lblRoulette4SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette4SM.Name = "lblRoulette4SM";
            this.lblRoulette4SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette4SM.TabIndex = 28;
            this.lblRoulette4SM.Text = "4";
            // 
            // lblRoulette3SM
            // 
            this.lblRoulette3SM.AutoSize = true;
            this.lblRoulette3SM.Location = new System.Drawing.Point(609, 30);
            this.lblRoulette3SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette3SM.Name = "lblRoulette3SM";
            this.lblRoulette3SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette3SM.TabIndex = 27;
            this.lblRoulette3SM.Text = "3";
            // 
            // lblRoulette2SM
            // 
            this.lblRoulette2SM.AutoSize = true;
            this.lblRoulette2SM.Location = new System.Drawing.Point(598, 19);
            this.lblRoulette2SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette2SM.Name = "lblRoulette2SM";
            this.lblRoulette2SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette2SM.TabIndex = 26;
            this.lblRoulette2SM.Text = "2";
            // 
            // lblRoulette1SM
            // 
            this.lblRoulette1SM.AutoSize = true;
            this.lblRoulette1SM.Location = new System.Drawing.Point(584, 13);
            this.lblRoulette1SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette1SM.Name = "lblRoulette1SM";
            this.lblRoulette1SM.Size = new System.Drawing.Size(13, 13);
            this.lblRoulette1SM.TabIndex = 25;
            this.lblRoulette1SM.Text = "1";
            // 
            // lblBetsLostSM
            // 
            this.lblBetsLostSM.AutoSize = true;
            this.lblBetsLostSM.Location = new System.Drawing.Point(58, 456);
            this.lblBetsLostSM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBetsLostSM.Name = "lblBetsLostSM";
            this.lblBetsLostSM.Size = new System.Drawing.Size(13, 13);
            this.lblBetsLostSM.TabIndex = 23;
            this.lblBetsLostSM.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 456);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "bets lost:";
            // 
            // lblBetsWonSM
            // 
            this.lblBetsWonSM.AutoSize = true;
            this.lblBetsWonSM.Location = new System.Drawing.Point(58, 435);
            this.lblBetsWonSM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBetsWonSM.Name = "lblBetsWonSM";
            this.lblBetsWonSM.Size = new System.Drawing.Size(13, 13);
            this.lblBetsWonSM.TabIndex = 21;
            this.lblBetsWonSM.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 435);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "bets won:";
            // 
            // lblBettingOnSM
            // 
            this.lblBettingOnSM.AutoSize = true;
            this.lblBettingOnSM.Location = new System.Drawing.Point(66, 33);
            this.lblBettingOnSM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBettingOnSM.Name = "lblBettingOnSM";
            this.lblBettingOnSM.Size = new System.Drawing.Size(54, 13);
            this.lblBettingOnSM.TabIndex = 19;
            this.lblBettingOnSM.Text = "no bet set";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 33);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "your bet:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 184);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "how many coins:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 254);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "how many coins:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 129);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "how many coins:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 67);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "how many coins:";
            // 
            // tbxBet3SM
            // 
            this.tbxBet3SM.Location = new System.Drawing.Point(110, 184);
            this.tbxBet3SM.Margin = new System.Windows.Forms.Padding(2);
            this.tbxBet3SM.Name = "tbxBet3SM";
            this.tbxBet3SM.Size = new System.Drawing.Size(76, 20);
            this.tbxBet3SM.TabIndex = 13;
            // 
            // tbxBet4SM
            // 
            this.tbxBet4SM.Location = new System.Drawing.Point(110, 252);
            this.tbxBet4SM.Margin = new System.Windows.Forms.Padding(2);
            this.tbxBet4SM.Name = "tbxBet4SM";
            this.tbxBet4SM.Size = new System.Drawing.Size(76, 20);
            this.tbxBet4SM.TabIndex = 12;
            // 
            // tbxBet1SM
            // 
            this.tbxBet1SM.Location = new System.Drawing.Point(110, 65);
            this.tbxBet1SM.Margin = new System.Windows.Forms.Padding(2);
            this.tbxBet1SM.Name = "tbxBet1SM";
            this.tbxBet1SM.Size = new System.Drawing.Size(76, 20);
            this.tbxBet1SM.TabIndex = 11;
            // 
            // tbxBet2SM
            // 
            this.tbxBet2SM.Location = new System.Drawing.Point(110, 127);
            this.tbxBet2SM.Margin = new System.Windows.Forms.Padding(2);
            this.tbxBet2SM.Name = "tbxBet2SM";
            this.tbxBet2SM.Size = new System.Drawing.Size(76, 20);
            this.tbxBet2SM.TabIndex = 10;
            // 
            // btnBet4SM
            // 
            this.btnBet4SM.Location = new System.Drawing.Point(20, 270);
            this.btnBet4SM.Margin = new System.Windows.Forms.Padding(2);
            this.btnBet4SM.Name = "btnBet4SM";
            this.btnBet4SM.Size = new System.Drawing.Size(80, 19);
            this.btnBet4SM.TabIndex = 9;
            this.btnBet4SM.Text = "bet on racer 4";
            this.btnBet4SM.UseVisualStyleBackColor = true;
            this.btnBet4SM.Click += new System.EventHandler(this.btnBet4SM_Click);
            // 
            // btnBet3SM
            // 
            this.btnBet3SM.Location = new System.Drawing.Point(20, 199);
            this.btnBet3SM.Margin = new System.Windows.Forms.Padding(2);
            this.btnBet3SM.Name = "btnBet3SM";
            this.btnBet3SM.Size = new System.Drawing.Size(80, 19);
            this.btnBet3SM.TabIndex = 8;
            this.btnBet3SM.Text = "bet on racer 3";
            this.btnBet3SM.UseVisualStyleBackColor = true;
            this.btnBet3SM.Click += new System.EventHandler(this.btnBet3SM_Click);
            // 
            // btnBet2SM
            // 
            this.btnBet2SM.Location = new System.Drawing.Point(20, 144);
            this.btnBet2SM.Margin = new System.Windows.Forms.Padding(2);
            this.btnBet2SM.Name = "btnBet2SM";
            this.btnBet2SM.Size = new System.Drawing.Size(80, 19);
            this.btnBet2SM.TabIndex = 7;
            this.btnBet2SM.Text = "bet on racer 2";
            this.btnBet2SM.UseVisualStyleBackColor = true;
            this.btnBet2SM.Click += new System.EventHandler(this.btnBet2SM_Click);
            // 
            // btnBet1SM
            // 
            this.btnBet1SM.Location = new System.Drawing.Point(20, 83);
            this.btnBet1SM.Margin = new System.Windows.Forms.Padding(2);
            this.btnBet1SM.Name = "btnBet1SM";
            this.btnBet1SM.Size = new System.Drawing.Size(80, 19);
            this.btnBet1SM.TabIndex = 6;
            this.btnBet1SM.Text = "bet on racer 1";
            this.btnBet1SM.UseVisualStyleBackColor = true;
            this.btnBet1SM.Click += new System.EventHandler(this.btnBet1SM_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 241);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "racer 4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 171);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "racer 3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 116);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "racer 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "racer 1";
            // 
            // lblCoinsSM
            // 
            this.lblCoinsSM.AutoSize = true;
            this.lblCoinsSM.Location = new System.Drawing.Point(76, 12);
            this.lblCoinsSM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCoinsSM.Name = "lblCoinsSM";
            this.lblCoinsSM.Size = new System.Drawing.Size(19, 13);
            this.lblCoinsSM.TabIndex = 1;
            this.lblCoinsSM.Text = "50";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "your coins:";
            // 
            // lblRoulette21SM
            // 
            this.lblRoulette21SM.AutoSize = true;
            this.lblRoulette21SM.Location = new System.Drawing.Point(530, 190);
            this.lblRoulette21SM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRoulette21SM.Name = "lblRoulette21SM";
            this.lblRoulette21SM.Size = new System.Drawing.Size(19, 13);
            this.lblRoulette21SM.TabIndex = 46;
            this.lblRoulette21SM.Text = "21";
            // 
            // tbpstartSM
            // 
            this.tbpstartSM.Controls.Add(this.btnStartScreen);
            this.tbpstartSM.Controls.Add(this.pbxStartScreen2SM);
            this.tbpstartSM.Controls.Add(this.pbxstartSM);
            this.tbpstartSM.Location = new System.Drawing.Point(4, 22);
            this.tbpstartSM.Margin = new System.Windows.Forms.Padding(2);
            this.tbpstartSM.Name = "tbpstartSM";
            this.tbpstartSM.Padding = new System.Windows.Forms.Padding(2);
            this.tbpstartSM.Size = new System.Drawing.Size(921, 490);
            this.tbpstartSM.TabIndex = 3;
            this.tbpstartSM.Text = "start screen";
            this.tbpstartSM.UseVisualStyleBackColor = true;
            // 
            // btnStartScreen
            // 
            this.btnStartScreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartScreen.Location = new System.Drawing.Point(369, 230);
            this.btnStartScreen.Margin = new System.Windows.Forms.Padding(2);
            this.btnStartScreen.Name = "btnStartScreen";
            this.btnStartScreen.Size = new System.Drawing.Size(153, 46);
            this.btnStartScreen.TabIndex = 1;
            this.btnStartScreen.Text = "start racing";
            this.btnStartScreen.UseVisualStyleBackColor = true;
            this.btnStartScreen.Click += new System.EventHandler(this.btnStartScreen_Click);
            // 
            // pbxStartScreen2SM
            // 
            this.pbxStartScreen2SM.Image = ((System.Drawing.Image)(resources.GetObject("pbxStartScreen2SM.Image")));
            this.pbxStartScreen2SM.Location = new System.Drawing.Point(0, 0);
            this.pbxStartScreen2SM.Name = "pbxStartScreen2SM";
            this.pbxStartScreen2SM.Size = new System.Drawing.Size(921, 490);
            this.pbxStartScreen2SM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxStartScreen2SM.TabIndex = 28;
            this.pbxStartScreen2SM.TabStop = false;
            this.pbxStartScreen2SM.Click += new System.EventHandler(this.pbxStartScreen2SM_Click);
            // 
            // pbxstartSM
            // 
            this.pbxstartSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxstartSM.Image")));
            this.pbxstartSM.Location = new System.Drawing.Point(0, 0);
            this.pbxstartSM.Margin = new System.Windows.Forms.Padding(2);
            this.pbxstartSM.Name = "pbxstartSM";
            this.pbxstartSM.Size = new System.Drawing.Size(921, 493);
            this.pbxstartSM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxstartSM.TabIndex = 0;
            this.pbxstartSM.TabStop = false;
            this.pbxstartSM.Click += new System.EventHandler(this.pbxstartSM_Click);
            // 
            // tbpMainHelpSM
            // 
            this.tbpMainHelpSM.Controls.Add(this.gbxHelpCasinoSM);
            this.tbpMainHelpSM.Controls.Add(this.gbxHelpSettingsSM);
            this.tbpMainHelpSM.Controls.Add(this.gbxHelpRaceSM);
            this.tbpMainHelpSM.Location = new System.Drawing.Point(4, 22);
            this.tbpMainHelpSM.Name = "tbpMainHelpSM";
            this.tbpMainHelpSM.Padding = new System.Windows.Forms.Padding(3);
            this.tbpMainHelpSM.Size = new System.Drawing.Size(921, 490);
            this.tbpMainHelpSM.TabIndex = 4;
            this.tbpMainHelpSM.Text = "help";
            this.tbpMainHelpSM.UseVisualStyleBackColor = true;
            // 
            // gbxHelpCasinoSM
            // 
            this.gbxHelpCasinoSM.Controls.Add(this.btnToRaceSM);
            this.gbxHelpCasinoSM.Controls.Add(this.pbxHelpWonSM);
            this.gbxHelpCasinoSM.Controls.Add(this.pbxHelpRouletteSM);
            this.gbxHelpCasinoSM.Controls.Add(this.pbxHelpCloggingSM);
            this.gbxHelpCasinoSM.Controls.Add(this.pbxHelpBetSM);
            this.gbxHelpCasinoSM.Controls.Add(this.pbxHelpCoinsSM);
            this.gbxHelpCasinoSM.Location = new System.Drawing.Point(0, 0);
            this.gbxHelpCasinoSM.Name = "gbxHelpCasinoSM";
            this.gbxHelpCasinoSM.Size = new System.Drawing.Size(921, 490);
            this.gbxHelpCasinoSM.TabIndex = 8;
            this.gbxHelpCasinoSM.TabStop = false;
            // 
            // btnToRaceSM
            // 
            this.btnToRaceSM.Location = new System.Drawing.Point(833, 461);
            this.btnToRaceSM.Name = "btnToRaceSM";
            this.btnToRaceSM.Size = new System.Drawing.Size(85, 23);
            this.btnToRaceSM.TabIndex = 1;
            this.btnToRaceSM.Text = "Back to race";
            this.btnToRaceSM.UseVisualStyleBackColor = true;
            this.btnToRaceSM.Click += new System.EventHandler(this.btnToRaceSM_Click);
            // 
            // pbxHelpWonSM
            // 
            this.pbxHelpWonSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpWonSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpWonSM.Image")));
            this.pbxHelpWonSM.Location = new System.Drawing.Point(5, 437);
            this.pbxHelpWonSM.Name = "pbxHelpWonSM";
            this.pbxHelpWonSM.Size = new System.Drawing.Size(75, 50);
            this.pbxHelpWonSM.TabIndex = 0;
            this.pbxHelpWonSM.TabStop = false;
            this.pbxHelpWonSM.Click += new System.EventHandler(this.pbxHelpWonSM_Click);
            // 
            // pbxHelpRouletteSM
            // 
            this.pbxHelpRouletteSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpRouletteSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpRouletteSM.Image")));
            this.pbxHelpRouletteSM.Location = new System.Drawing.Point(409, 19);
            this.pbxHelpRouletteSM.Name = "pbxHelpRouletteSM";
            this.pbxHelpRouletteSM.Size = new System.Drawing.Size(317, 328);
            this.pbxHelpRouletteSM.TabIndex = 0;
            this.pbxHelpRouletteSM.TabStop = false;
            this.pbxHelpRouletteSM.Click += new System.EventHandler(this.pbxHelpRouletteSM_Click);
            // 
            // pbxHelpCloggingSM
            // 
            this.pbxHelpCloggingSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpCloggingSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpCloggingSM.Image")));
            this.pbxHelpCloggingSM.Location = new System.Drawing.Point(767, 0);
            this.pbxHelpCloggingSM.Name = "pbxHelpCloggingSM";
            this.pbxHelpCloggingSM.Size = new System.Drawing.Size(154, 146);
            this.pbxHelpCloggingSM.TabIndex = 0;
            this.pbxHelpCloggingSM.TabStop = false;
            this.pbxHelpCloggingSM.Click += new System.EventHandler(this.pbxHelpCloggingSM_Click);
            // 
            // pbxHelpBetSM
            // 
            this.pbxHelpBetSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpBetSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpBetSM.Image")));
            this.pbxHelpBetSM.Location = new System.Drawing.Point(3, 31);
            this.pbxHelpBetSM.Name = "pbxHelpBetSM";
            this.pbxHelpBetSM.Size = new System.Drawing.Size(298, 276);
            this.pbxHelpBetSM.TabIndex = 0;
            this.pbxHelpBetSM.TabStop = false;
            this.pbxHelpBetSM.Click += new System.EventHandler(this.pbxHelpBetSM_Click);
            // 
            // pbxHelpCoinsSM
            // 
            this.pbxHelpCoinsSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpCoinsSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpCoinsSM.Image")));
            this.pbxHelpCoinsSM.Location = new System.Drawing.Point(3, 6);
            this.pbxHelpCoinsSM.Name = "pbxHelpCoinsSM";
            this.pbxHelpCoinsSM.Size = new System.Drawing.Size(77, 19);
            this.pbxHelpCoinsSM.TabIndex = 0;
            this.pbxHelpCoinsSM.TabStop = false;
            this.pbxHelpCoinsSM.Click += new System.EventHandler(this.pbxHelpCoinsSM_Click);
            // 
            // gbxHelpSettingsSM
            // 
            this.gbxHelpSettingsSM.Controls.Add(this.btnToCasinoSM);
            this.gbxHelpSettingsSM.Controls.Add(this.pbxHelpSetupSM);
            this.gbxHelpSettingsSM.Controls.Add(this.pbxHelpSloggingSM);
            this.gbxHelpSettingsSM.Controls.Add(this.pbxHelpSpeedSM);
            this.gbxHelpSettingsSM.Location = new System.Drawing.Point(126, 468);
            this.gbxHelpSettingsSM.Name = "gbxHelpSettingsSM";
            this.gbxHelpSettingsSM.Size = new System.Drawing.Size(102, 68);
            this.gbxHelpSettingsSM.TabIndex = 7;
            this.gbxHelpSettingsSM.TabStop = false;
            // 
            // btnToCasinoSM
            // 
            this.btnToCasinoSM.Location = new System.Drawing.Point(837, 458);
            this.btnToCasinoSM.Name = "btnToCasinoSM";
            this.btnToCasinoSM.Size = new System.Drawing.Size(75, 23);
            this.btnToCasinoSM.TabIndex = 1;
            this.btnToCasinoSM.Text = "next";
            this.btnToCasinoSM.UseVisualStyleBackColor = true;
            this.btnToCasinoSM.Click += new System.EventHandler(this.btnToCasinoSM_Click);
            // 
            // pbxHelpSetupSM
            // 
            this.pbxHelpSetupSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpSetupSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpSetupSM.Image")));
            this.pbxHelpSetupSM.Location = new System.Drawing.Point(6, 204);
            this.pbxHelpSetupSM.Name = "pbxHelpSetupSM";
            this.pbxHelpSetupSM.Size = new System.Drawing.Size(343, 146);
            this.pbxHelpSetupSM.TabIndex = 0;
            this.pbxHelpSetupSM.TabStop = false;
            this.pbxHelpSetupSM.Click += new System.EventHandler(this.pbxHelpSetupSM_Click);
            // 
            // pbxHelpSloggingSM
            // 
            this.pbxHelpSloggingSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpSloggingSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpSloggingSM.Image")));
            this.pbxHelpSloggingSM.Location = new System.Drawing.Point(665, 16);
            this.pbxHelpSloggingSM.Name = "pbxHelpSloggingSM";
            this.pbxHelpSloggingSM.Size = new System.Drawing.Size(250, 205);
            this.pbxHelpSloggingSM.TabIndex = 0;
            this.pbxHelpSloggingSM.TabStop = false;
            this.pbxHelpSloggingSM.Click += new System.EventHandler(this.pbxHelpSloggingSM_Click);
            // 
            // pbxHelpSpeedSM
            // 
            this.pbxHelpSpeedSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpSpeedSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpSpeedSM.Image")));
            this.pbxHelpSpeedSM.Location = new System.Drawing.Point(6, 19);
            this.pbxHelpSpeedSM.Name = "pbxHelpSpeedSM";
            this.pbxHelpSpeedSM.Size = new System.Drawing.Size(157, 74);
            this.pbxHelpSpeedSM.TabIndex = 0;
            this.pbxHelpSpeedSM.TabStop = false;
            this.pbxHelpSpeedSM.Click += new System.EventHandler(this.pbxHelpSpeedSM_Click);
            // 
            // gbxHelpRaceSM
            // 
            this.gbxHelpRaceSM.Controls.Add(this.pbxHelpRaceSM);
            this.gbxHelpRaceSM.Controls.Add(this.btnToSettingsSM);
            this.gbxHelpRaceSM.Controls.Add(this.pbxhelpBtnSM);
            this.gbxHelpRaceSM.Controls.Add(this.pbxHelpTimeSM);
            this.gbxHelpRaceSM.Controls.Add(this.pbxHelpRankingSM);
            this.gbxHelpRaceSM.Controls.Add(this.pbxHelpDrawSM);
            this.gbxHelpRaceSM.Controls.Add(this.pbxHelpStageSM);
            this.gbxHelpRaceSM.Location = new System.Drawing.Point(8, 465);
            this.gbxHelpRaceSM.Name = "gbxHelpRaceSM";
            this.gbxHelpRaceSM.Size = new System.Drawing.Size(103, 57);
            this.gbxHelpRaceSM.TabIndex = 7;
            this.gbxHelpRaceSM.TabStop = false;
            // 
            // pbxHelpRaceSM
            // 
            this.pbxHelpRaceSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpRaceSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpRaceSM.Image")));
            this.pbxHelpRaceSM.Location = new System.Drawing.Point(3, 3);
            this.pbxHelpRaceSM.Name = "pbxHelpRaceSM";
            this.pbxHelpRaceSM.Size = new System.Drawing.Size(915, 269);
            this.pbxHelpRaceSM.TabIndex = 0;
            this.pbxHelpRaceSM.TabStop = false;
            this.pbxHelpRaceSM.Click += new System.EventHandler(this.pbxHelpRaceSM_Click);
            // 
            // btnToSettingsSM
            // 
            this.btnToSettingsSM.Location = new System.Drawing.Point(836, 458);
            this.btnToSettingsSM.Name = "btnToSettingsSM";
            this.btnToSettingsSM.Size = new System.Drawing.Size(75, 23);
            this.btnToSettingsSM.TabIndex = 6;
            this.btnToSettingsSM.Text = "next";
            this.btnToSettingsSM.UseVisualStyleBackColor = true;
            this.btnToSettingsSM.Click += new System.EventHandler(this.btnToSettingsSM_Click);
            // 
            // pbxhelpBtnSM
            // 
            this.pbxhelpBtnSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxhelpBtnSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxhelpBtnSM.Image")));
            this.pbxhelpBtnSM.Location = new System.Drawing.Point(3, 278);
            this.pbxhelpBtnSM.Name = "pbxhelpBtnSM";
            this.pbxhelpBtnSM.Size = new System.Drawing.Size(100, 87);
            this.pbxhelpBtnSM.TabIndex = 1;
            this.pbxhelpBtnSM.TabStop = false;
            this.pbxhelpBtnSM.Click += new System.EventHandler(this.pbxhelpBtnSM_Click);
            // 
            // pbxHelpTimeSM
            // 
            this.pbxHelpTimeSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpTimeSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpTimeSM.Image")));
            this.pbxHelpTimeSM.Location = new System.Drawing.Point(105, 279);
            this.pbxHelpTimeSM.Name = "pbxHelpTimeSM";
            this.pbxHelpTimeSM.Size = new System.Drawing.Size(72, 21);
            this.pbxHelpTimeSM.TabIndex = 5;
            this.pbxHelpTimeSM.TabStop = false;
            this.pbxHelpTimeSM.Click += new System.EventHandler(this.pbxHelpTimeSM_Click);
            // 
            // pbxHelpRankingSM
            // 
            this.pbxHelpRankingSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpRankingSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpRankingSM.Image")));
            this.pbxHelpRankingSM.Location = new System.Drawing.Point(3, 371);
            this.pbxHelpRankingSM.Name = "pbxHelpRankingSM";
            this.pbxHelpRankingSM.Size = new System.Drawing.Size(69, 99);
            this.pbxHelpRankingSM.TabIndex = 2;
            this.pbxHelpRankingSM.TabStop = false;
            this.pbxHelpRankingSM.Click += new System.EventHandler(this.pbxHelpRankingSM_Click);
            // 
            // pbxHelpDrawSM
            // 
            this.pbxHelpDrawSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpDrawSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpDrawSM.Image")));
            this.pbxHelpDrawSM.Location = new System.Drawing.Point(540, 279);
            this.pbxHelpDrawSM.Name = "pbxHelpDrawSM";
            this.pbxHelpDrawSM.Size = new System.Drawing.Size(375, 130);
            this.pbxHelpDrawSM.TabIndex = 4;
            this.pbxHelpDrawSM.TabStop = false;
            this.pbxHelpDrawSM.Click += new System.EventHandler(this.pbxHelpDrawSM_Click);
            // 
            // pbxHelpStageSM
            // 
            this.pbxHelpStageSM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxHelpStageSM.Image = ((System.Drawing.Image)(resources.GetObject("pbxHelpStageSM.Image")));
            this.pbxHelpStageSM.Location = new System.Drawing.Point(113, 332);
            this.pbxHelpStageSM.Name = "pbxHelpStageSM";
            this.pbxHelpStageSM.Size = new System.Drawing.Size(275, 146);
            this.pbxHelpStageSM.TabIndex = 3;
            this.pbxHelpStageSM.TabStop = false;
            this.pbxHelpStageSM.Click += new System.EventHandler(this.pbxHelpStageSM_Click);
            // 
            // tbpMainAllLoggingSM
            // 
            this.tbpMainAllLoggingSM.Controls.Add(this.rtbAllLoggingSM);
            this.tbpMainAllLoggingSM.Location = new System.Drawing.Point(4, 22);
            this.tbpMainAllLoggingSM.Name = "tbpMainAllLoggingSM";
            this.tbpMainAllLoggingSM.Padding = new System.Windows.Forms.Padding(3);
            this.tbpMainAllLoggingSM.Size = new System.Drawing.Size(921, 490);
            this.tbpMainAllLoggingSM.TabIndex = 5;
            this.tbpMainAllLoggingSM.Text = "Logging";
            this.tbpMainAllLoggingSM.UseVisualStyleBackColor = true;
            // 
            // rtbAllLoggingSM
            // 
            this.rtbAllLoggingSM.Location = new System.Drawing.Point(0, 0);
            this.rtbAllLoggingSM.Name = "rtbAllLoggingSM";
            this.rtbAllLoggingSM.Size = new System.Drawing.Size(921, 490);
            this.rtbAllLoggingSM.TabIndex = 0;
            this.rtbAllLoggingSM.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.vieuwToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(930, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.creatorToolStripMenuItem,
            this.HelpToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(40, 20);
            this.toolStripMenuItem1.Text = "info";
            // 
            // creatorToolStripMenuItem
            // 
            this.creatorToolStripMenuItem.Name = "creatorToolStripMenuItem";
            this.creatorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.C)));
            this.creatorToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.creatorToolStripMenuItem.Text = "creator";
            this.creatorToolStripMenuItem.Click += new System.EventHandler(this.creatorToolStripMenuItem_Click);
            // 
            // HelpToolStripMenuItem
            // 
            this.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem";
            this.HelpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.HelpToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.HelpToolStripMenuItem.Text = "help";
            this.HelpToolStripMenuItem.Click += new System.EventHandler(this.HelpToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.quitToolStripMenuItem.Text = "quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // vieuwToolStripMenuItem
            // 
            this.vieuwToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem,
            this.theRaceToolStripMenuItem,
            this.loggingToolStripMenuItem,
            this.casinoToolStripMenuItem});
            this.vieuwToolStripMenuItem.Name = "vieuwToolStripMenuItem";
            this.vieuwToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.vieuwToolStripMenuItem.Text = "view";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.settingsToolStripMenuItem.Text = "settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // theRaceToolStripMenuItem
            // 
            this.theRaceToolStripMenuItem.Name = "theRaceToolStripMenuItem";
            this.theRaceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F2)));
            this.theRaceToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.theRaceToolStripMenuItem.Text = "the race";
            this.theRaceToolStripMenuItem.Click += new System.EventHandler(this.theRaceToolStripMenuItem_Click);
            // 
            // loggingToolStripMenuItem
            // 
            this.loggingToolStripMenuItem.Name = "loggingToolStripMenuItem";
            this.loggingToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F3)));
            this.loggingToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.loggingToolStripMenuItem.Text = "logging";
            this.loggingToolStripMenuItem.Click += new System.EventHandler(this.loggingToolStripMenuItem_Click);
            // 
            // casinoToolStripMenuItem
            // 
            this.casinoToolStripMenuItem.Name = "casinoToolStripMenuItem";
            this.casinoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.casinoToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.casinoToolStripMenuItem.Text = "casino";
            this.casinoToolStripMenuItem.Click += new System.EventHandler(this.casinoToolStripMenuItem_Click);
            // 
            // tmrRouletteSM
            // 
            this.tmrRouletteSM.Tick += new System.EventHandler(this.tmrRoulette_Tick);
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.radioButton37);
            this.panel37.Location = new System.Drawing.Point(325, 402);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(33, 28);
            this.panel37.TabIndex = 79;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(8, 6);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(14, 13);
            this.radioButton37.TabIndex = 24;
            this.radioButton37.TabStop = true;
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.radioButton38);
            this.panel38.Location = new System.Drawing.Point(543, 402);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(33, 28);
            this.panel38.TabIndex = 80;
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(8, 6);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(14, 13);
            this.radioButton38.TabIndex = 24;
            this.radioButton38.TabStop = true;
            this.radioButton38.UseVisualStyleBackColor = true;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.radioButton39);
            this.panel39.Location = new System.Drawing.Point(574, 402);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(33, 28);
            this.panel39.TabIndex = 81;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(8, 6);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(14, 13);
            this.radioButton39.TabIndex = 24;
            this.radioButton39.TabStop = true;
            this.radioButton39.UseVisualStyleBackColor = true;
            // 
            // panel40
            // 
            this.panel40.Controls.Add(this.radioButton40);
            this.panel40.Location = new System.Drawing.Point(605, 402);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(33, 28);
            this.panel40.TabIndex = 82;
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(8, 6);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(14, 13);
            this.radioButton40.TabIndex = 24;
            this.radioButton40.TabStop = true;
            this.radioButton40.UseVisualStyleBackColor = true;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.radioButton41);
            this.panel41.Location = new System.Drawing.Point(636, 402);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(33, 28);
            this.panel41.TabIndex = 83;
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(8, 6);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(14, 13);
            this.radioButton41.TabIndex = 24;
            this.radioButton41.TabStop = true;
            this.radioButton41.UseVisualStyleBackColor = true;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.radioButton42);
            this.panel42.Location = new System.Drawing.Point(450, 402);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(33, 28);
            this.panel42.TabIndex = 84;
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(8, 6);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(14, 13);
            this.radioButton42.TabIndex = 24;
            this.radioButton42.TabStop = true;
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.radioButton43);
            this.panel43.Location = new System.Drawing.Point(388, 402);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(33, 28);
            this.panel43.TabIndex = 85;
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(8, 6);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(14, 13);
            this.radioButton43.TabIndex = 24;
            this.radioButton43.TabStop = true;
            this.radioButton43.UseVisualStyleBackColor = true;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.radioButton44);
            this.panel44.Location = new System.Drawing.Point(419, 402);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(33, 28);
            this.panel44.TabIndex = 86;
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(8, 6);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(14, 13);
            this.radioButton44.TabIndex = 24;
            this.radioButton44.TabStop = true;
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.radioButton45);
            this.panel45.Location = new System.Drawing.Point(481, 402);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(33, 28);
            this.panel45.TabIndex = 87;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(8, 6);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(14, 13);
            this.radioButton45.TabIndex = 24;
            this.radioButton45.TabStop = true;
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // panel46
            // 
            this.panel46.Controls.Add(this.radioButton46);
            this.panel46.Location = new System.Drawing.Point(512, 402);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(33, 28);
            this.panel46.TabIndex = 88;
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Location = new System.Drawing.Point(8, 6);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(14, 13);
            this.radioButton46.TabIndex = 24;
            this.radioButton46.TabStop = true;
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.radioButton47);
            this.panel47.Controls.Add(this.panel48);
            this.panel47.Controls.Add(this.panel49);
            this.panel47.Controls.Add(this.panel50);
            this.panel47.Controls.Add(this.panel51);
            this.panel47.Controls.Add(this.panel52);
            this.panel47.Controls.Add(this.panel53);
            this.panel47.Controls.Add(this.panel54);
            this.panel47.Controls.Add(this.panel55);
            this.panel47.Controls.Add(this.panel56);
            this.panel47.Controls.Add(this.panel57);
            this.panel47.Controls.Add(this.panel58);
            this.panel47.Controls.Add(this.panel59);
            this.panel47.Location = new System.Drawing.Point(357, 402);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(33, 28);
            this.panel47.TabIndex = 89;
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(8, 6);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(14, 13);
            this.radioButton47.TabIndex = 24;
            this.radioButton47.TabStop = true;
            this.radioButton47.UseVisualStyleBackColor = true;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.radioButton48);
            this.panel48.Location = new System.Drawing.Point(-32, 28);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(33, 28);
            this.panel48.TabIndex = 67;
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Location = new System.Drawing.Point(8, 6);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(14, 13);
            this.radioButton48.TabIndex = 24;
            this.radioButton48.TabStop = true;
            this.radioButton48.UseVisualStyleBackColor = true;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.radioButton49);
            this.panel49.Location = new System.Drawing.Point(31, 28);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(33, 28);
            this.panel49.TabIndex = 73;
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(8, 6);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(14, 13);
            this.radioButton49.TabIndex = 24;
            this.radioButton49.TabStop = true;
            this.radioButton49.UseVisualStyleBackColor = true;
            // 
            // panel50
            // 
            this.panel50.Controls.Add(this.radioButton50);
            this.panel50.Location = new System.Drawing.Point(-63, 28);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(33, 28);
            this.panel50.TabIndex = 66;
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(8, 6);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(14, 13);
            this.radioButton50.TabIndex = 24;
            this.radioButton50.TabStop = true;
            this.radioButton50.UseVisualStyleBackColor = true;
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.radioButton51);
            this.panel51.Location = new System.Drawing.Point(186, 28);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(33, 28);
            this.panel51.TabIndex = 68;
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(8, 6);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(14, 13);
            this.radioButton51.TabIndex = 24;
            this.radioButton51.TabStop = true;
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // panel52
            // 
            this.panel52.Controls.Add(this.radioButton52);
            this.panel52.Location = new System.Drawing.Point(0, 28);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(33, 28);
            this.panel52.TabIndex = 77;
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(8, 6);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(14, 13);
            this.radioButton52.TabIndex = 24;
            this.radioButton52.TabStop = true;
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.radioButton53);
            this.panel53.Location = new System.Drawing.Point(155, 28);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(33, 28);
            this.panel53.TabIndex = 76;
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(8, 6);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(14, 13);
            this.radioButton53.TabIndex = 24;
            this.radioButton53.TabStop = true;
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // panel54
            // 
            this.panel54.Controls.Add(this.radioButton54);
            this.panel54.Location = new System.Drawing.Point(217, 28);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(33, 28);
            this.panel54.TabIndex = 69;
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(8, 6);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(14, 13);
            this.radioButton54.TabIndex = 24;
            this.radioButton54.TabStop = true;
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // panel55
            // 
            this.panel55.Controls.Add(this.radioButton55);
            this.panel55.Location = new System.Drawing.Point(124, 28);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(33, 28);
            this.panel55.TabIndex = 75;
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(8, 6);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(14, 13);
            this.radioButton55.TabIndex = 24;
            this.radioButton55.TabStop = true;
            this.radioButton55.UseVisualStyleBackColor = true;
            // 
            // panel56
            // 
            this.panel56.Controls.Add(this.radioButton56);
            this.panel56.Location = new System.Drawing.Point(62, 28);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(33, 28);
            this.panel56.TabIndex = 74;
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(8, 6);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(14, 13);
            this.radioButton56.TabIndex = 24;
            this.radioButton56.TabStop = true;
            this.radioButton56.UseVisualStyleBackColor = true;
            // 
            // panel57
            // 
            this.panel57.Controls.Add(this.radioButton57);
            this.panel57.Location = new System.Drawing.Point(248, 28);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(33, 28);
            this.panel57.TabIndex = 70;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(8, 6);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(14, 13);
            this.radioButton57.TabIndex = 24;
            this.radioButton57.TabStop = true;
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // panel58
            // 
            this.panel58.Controls.Add(this.radioButton58);
            this.panel58.Location = new System.Drawing.Point(93, 28);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(33, 28);
            this.panel58.TabIndex = 72;
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Location = new System.Drawing.Point(8, 6);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(14, 13);
            this.radioButton58.TabIndex = 24;
            this.radioButton58.TabStop = true;
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // panel59
            // 
            this.panel59.Controls.Add(this.radioButton59);
            this.panel59.Location = new System.Drawing.Point(279, 28);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(33, 28);
            this.panel59.TabIndex = 71;
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(8, 6);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(14, 13);
            this.radioButton59.TabIndex = 24;
            this.radioButton59.TabStop = true;
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // panel60
            // 
            this.panel60.Controls.Add(this.radioButton60);
            this.panel60.Location = new System.Drawing.Point(294, 402);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(33, 28);
            this.panel60.TabIndex = 78;
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(8, 6);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(14, 13);
            this.radioButton60.TabIndex = 24;
            this.radioButton60.TabStop = true;
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // tmrRaceSM
            // 
            this.tmrRaceSM.Tick += new System.EventHandler(this.tmrRaceSM_Tick);
            // 
            // tmrStartScreenSM
            // 
            this.tmrStartScreenSM.Tick += new System.EventHandler(this.tmrStartScreenSM_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 541);
            this.Controls.Add(this.tbcMainSM);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer1SM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer2SM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer3SM)).EndInit();
            this.tbcMainSM.ResumeLayout(false);
            this.tbpMainRaceSM.ResumeLayout(false);
            this.tbpMainRaceSM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer4SM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer4TrailSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer3TrailSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer1TrailSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRacer2TrailSM)).EndInit();
            this.tbpMainSettingsSM.ResumeLayout(false);
            this.tbpMainSettingsSM.PerformLayout();
            this.tbpMainCasinoSM.ResumeLayout(false);
            this.tbpMainCasinoSM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.gbxrouletteSM.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel61.ResumeLayout(false);
            this.panel61.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.tbpstartSM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxStartScreen2SM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxstartSM)).EndInit();
            this.tbpMainHelpSM.ResumeLayout(false);
            this.gbxHelpCasinoSM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpWonSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpRouletteSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpCloggingSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpBetSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpCoinsSM)).EndInit();
            this.gbxHelpSettingsSM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpSetupSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpSloggingSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpSpeedSM)).EndInit();
            this.gbxHelpRaceSM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpRaceSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxhelpBtnSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpTimeSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpRankingSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpDrawSM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxHelpStageSM)).EndInit();
            this.tbpMainAllLoggingSM.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.panel50.ResumeLayout(false);
            this.panel50.PerformLayout();
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.panel56.ResumeLayout(false);
            this.panel56.PerformLayout();
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.panel58.ResumeLayout(false);
            this.panel58.PerformLayout();
            this.panel59.ResumeLayout(false);
            this.panel59.PerformLayout();
            this.panel60.ResumeLayout(false);
            this.panel60.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnlFinishSM;
        private System.Windows.Forms.PictureBox pbxRacer1SM;
        private System.Windows.Forms.PictureBox pbxRacer2SM;
        private System.Windows.Forms.PictureBox pbxRacer3SM;
        private System.Windows.Forms.Button btnGoSM;
        private System.Windows.Forms.Button btnResetSM;
        private System.Windows.Forms.TabControl tbcMainSM;
        private System.Windows.Forms.TabPage tbpMainRaceSM;
        private System.Windows.Forms.TabPage tbpMainSettingsSM;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vieuwToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theRaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem casinoToolStripMenuItem;
        private System.Windows.Forms.TabPage tbpMainCasinoSM;
        private System.Windows.Forms.Label lblRank1SM;
        private System.Windows.Forms.Label lblRank2SM;
        private System.Windows.Forms.Label lblRacer4SM;
        private System.Windows.Forms.Label lblRacer3SM;
        private System.Windows.Forms.Label lblRacer2SM;
        private System.Windows.Forms.Label lblRacer1SM;
        private System.Windows.Forms.Label lblRank4SM;
        private System.Windows.Forms.Label lblRank3SM;
        private System.Windows.Forms.TextBox tbxBet3SM;
        private System.Windows.Forms.TextBox tbxBet4SM;
        private System.Windows.Forms.TextBox tbxBet1SM;
        private System.Windows.Forms.TextBox tbxBet2SM;
        private System.Windows.Forms.Button btnBet4SM;
        private System.Windows.Forms.Button btnBet3SM;
        private System.Windows.Forms.Button btnBet2SM;
        private System.Windows.Forms.Button btnBet1SM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCoinsSM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblBettingOnSM;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblBetsWonSM;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblBetsLostSM;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton rbnRoulette1SM;
        private System.Windows.Forms.Label lblRoulette1SM;
        private System.Windows.Forms.Label lblRoulette8SM;
        private System.Windows.Forms.Label lblRoulette7SM;
        private System.Windows.Forms.Label lblRoulette6SM;
        private System.Windows.Forms.Label lblRoulette5SM;
        private System.Windows.Forms.Label lblRoulette4SM;
        private System.Windows.Forms.Label lblRoulette3SM;
        private System.Windows.Forms.Label lblRoulette2SM;
        private System.Windows.Forms.Label lblRoulette12SM;
        private System.Windows.Forms.Label lblRoulette10SM;
        private System.Windows.Forms.Label lblRoulette14SM;
        private System.Windows.Forms.Label lblRoulette11SM;
        private System.Windows.Forms.Label lblRoulette9SM;
        private System.Windows.Forms.Label lblRoulette13SM;
        private System.Windows.Forms.Label lblRoulette24SM;
        private System.Windows.Forms.Label lblRoulette20SM;
        private System.Windows.Forms.Label lblRoulette17SM;
        private System.Windows.Forms.Label lblRoulette16SM;
        private System.Windows.Forms.Label lblRoulette19SM;
        private System.Windows.Forms.Label lblRoulette18SM;
        private System.Windows.Forms.Label lblRoulette15SM;
        private System.Windows.Forms.Label lblRoulette23SM;
        private System.Windows.Forms.Label lblRoulette22SM;
        private System.Windows.Forms.Label lblRoulette21SM;
        private System.Windows.Forms.Label lblRoulette26SM;
        private System.Windows.Forms.Label lblRoulette27SM;
        private System.Windows.Forms.Label lblRoulette29SM;
        private System.Windows.Forms.Label lblRoulette28SM;
        private System.Windows.Forms.Label lblRoulette25SM;
        private System.Windows.Forms.Label lblRoulette33SM;
        private System.Windows.Forms.Label lblRoulette32SM;
        private System.Windows.Forms.Label lblRoulette31SM;
        private System.Windows.Forms.Label lblRoulette30SM;
        private System.Windows.Forms.Label lblRoulette36SM;
        private System.Windows.Forms.Label lblRoulette35SM;
        private System.Windows.Forms.Label lblRoulette34SM;
        private System.Windows.Forms.TextBox tbxRouletteSM;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnRouletteGoSM;
        private System.Windows.Forms.Timer tmrRouletteSM;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton rbnRoulette2SM;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton rbnRoulette9SM;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton rbnRoulette8SM;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RadioButton rbnRoulette7SM;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton rbnRoulette6SM;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RadioButton rbnRoulette5SM;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton rbnRoulette4SM;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rbnRoulette3SM;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.RadioButton rbnRoulette36SM;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.RadioButton rbnRoulette33SM;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.RadioButton rbnRoulette32SM;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.RadioButton rbnRoulette35SM;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.RadioButton rbnRoulette34SM;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.RadioButton rbnRoulette31SM;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.RadioButton rbnRoulette30SM;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.RadioButton rbnRoulette29SM;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.RadioButton rbnRoulette28SM;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.RadioButton rbnRoulette27SM;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.RadioButton rbnRoulette24SM;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.RadioButton rbnRoulette23SM;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.RadioButton rbnRoulette26SM;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.RadioButton rbnRoulette25SM;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.RadioButton rbnRoulette22SM;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.RadioButton rbnRoulette21SM;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.RadioButton rbnRoulette20SM;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.RadioButton rbnRoulette19SM;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton rbnRoulette18SM;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.RadioButton rbnRoulette15SM;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RadioButton rbnRoulette14SM;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.RadioButton rbnRoulette17SM;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.RadioButton rbnRoulette16SM;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RadioButton rbnRoulette13SM;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.RadioButton rbnRoulette12SM;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RadioButton rbnRoulette11SM;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.RadioButton rbnRoulette10SM;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.RadioButton rbnRoulette0SM;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label lblRoulette0SM;
        private System.Windows.Forms.GroupBox gbxrouletteSM;
        private System.Windows.Forms.TextBox txbMaxSpeedSM;
        private System.Windows.Forms.TextBox txbMinSpeedSM;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Button btnDefaultSM;
        private System.Windows.Forms.Label lblEngine2SM;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label lblEngine1SM;
        private System.Windows.Forms.Label lblStapsizeTick2SM;
        private System.Windows.Forms.Label lblStapsizeTick1SM;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button btnSetupRacers;
        private System.Windows.Forms.PictureBox pbxRacer4SM;
        private System.Windows.Forms.Timer tmrRaceSM;
        private System.Windows.Forms.Label lblRaceTimeSM;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label lblStapsizeTick4SM;
        private System.Windows.Forms.Label lblStapsizeTick3SM;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label lblEngine3SM;
        private System.Windows.Forms.Label lblEngine4SM;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.PictureBox pbxRacer1TrailSM;
        private System.Windows.Forms.PictureBox pbxRacer4TrailSM;
        private System.Windows.Forms.PictureBox pbxRacer3TrailSM;
        private System.Windows.Forms.PictureBox pbxRacer2TrailSM;
        private System.Windows.Forms.TabPage tbpstartSM;
        private System.Windows.Forms.PictureBox pbxstartSM;
        private System.Windows.Forms.ToolStripMenuItem creatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.Button btnAgainSM;
        private System.Windows.Forms.Button btnStartScreen;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txbRacerName4SM;
        private System.Windows.Forms.TextBox txbRacerName2SM;
        private System.Windows.Forms.TextBox txbRacerName1SM;
        private System.Windows.Forms.TextBox txbRacerName3SM;
        private System.Windows.Forms.RichTextBox rtbSettingsSM;
        private System.Windows.Forms.RichTextBox rtbCasinoSM;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel pnlpaintSM;
        private System.Windows.Forms.TabPage tbpMainHelpSM;
        private System.Windows.Forms.PictureBox pbxHelpRaceSM;
        private System.Windows.Forms.PictureBox pbxhelpBtnSM;
        private System.Windows.Forms.PictureBox pbxHelpStageSM;
        private System.Windows.Forms.PictureBox pbxHelpRankingSM;
        private System.Windows.Forms.PictureBox pbxHelpTimeSM;
        private System.Windows.Forms.PictureBox pbxHelpDrawSM;
        private System.Windows.Forms.Button btnToSettingsSM;
        private System.Windows.Forms.GroupBox gbxHelpRaceSM;
        private System.Windows.Forms.GroupBox gbxHelpSettingsSM;
        private System.Windows.Forms.PictureBox pbxHelpSpeedSM;
        private System.Windows.Forms.PictureBox pbxHelpSetupSM;
        private System.Windows.Forms.PictureBox pbxHelpSloggingSM;
        private System.Windows.Forms.GroupBox gbxHelpCasinoSM;
        private System.Windows.Forms.PictureBox pbxHelpWonSM;
        private System.Windows.Forms.PictureBox pbxHelpRouletteSM;
        private System.Windows.Forms.PictureBox pbxHelpCloggingSM;
        private System.Windows.Forms.PictureBox pbxHelpBetSM;
        private System.Windows.Forms.PictureBox pbxHelpCoinsSM;
        private System.Windows.Forms.Button btnToCasinoSM;
        private System.Windows.Forms.Button btnToRaceSM;
        private System.Windows.Forms.PictureBox pbxStartScreen2SM;
        private System.Windows.Forms.Timer tmrStartScreenSM;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TabPage tbpMainAllLoggingSM;
        private System.Windows.Forms.RichTextBox rtbAllLoggingSM;
        private System.Windows.Forms.ToolStripMenuItem loggingToolStripMenuItem;
    }
}

